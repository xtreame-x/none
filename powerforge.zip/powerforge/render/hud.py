"""HUD, minimap and banners.

Pure presentation: reads the simulation, writes only to the screen. The
damage-dealt meter is deliberately the loudest number on screen because the
design doc treats damage as the player's headline score, not health or loot.
"""
import pygame

from settings import (WINDOW_W, WINDOW_H, MAP_W, MAP_H, TILE, T_VOID, T_FLOOR,
                      T_FLOOR_ALT, T_WALL, T_BRIDGE, T_VILLAGE, T_CONDUIT,
                      C_HUD_BG, C_HUD_LINE, C_HP, C_CYAN, C_AMBER, C_RED,
                      C_WHITE, C_MAGENTA, PLAYER_HP, DASH_COOLDOWN)

PAD = 14
BAR_W = 236

MM_COLORS = {
    T_VOID: (8, 10, 16),
    T_FLOOR: (56, 68, 88),
    T_FLOOR_ALT: (64, 78, 100),
    T_WALL: (30, 38, 52),
    T_BRIDGE: (74, 86, 108),
    T_VILLAGE: (104, 84, 50),
    T_CONDUIT: (58, 120, 148),
}


class Hud:
    def __init__(self, world):
        pygame.font.init()
        self.f_small = pygame.font.Font(None, 19)
        self.f_mid = pygame.font.Font(None, 25)
        self.f_big = pygame.font.Font(None, 46)
        self.f_huge = pygame.font.Font(None, 64)
        self._cache = {}
        self.world = world
        self.minimap = self._build_minimap(world)
        self.mm_w = self.minimap.get_width()
        self.mm_h = self.minimap.get_height()
        self.mm_x = WINDOW_W - PAD - self.mm_w
        self.mm_y = PAD
        self.debug = False
        self.fps = 0.0
        self.step_ms = 0.0
        self.draw_ms = 0.0

    # ------------------------------------------------------------------ setup
    def _build_minimap(self, world):
        """One pixel per tile, baked once. 224x192 sits fine in the corner."""
        surf = pygame.Surface((MAP_W, MAP_H))
        for ty in range(MAP_H):
            for tx in range(MAP_W):
                surf.set_at((tx, ty), MM_COLORS[world.tile(tx, ty)])
        return surf.convert()

    def _text(self, s, font, col):
        key = (s, id(font), col)
        img = self._cache.get(key)
        if img is None:
            img = font.render(s, True, col)
            self._cache[key] = img
            if len(self._cache) > 512:                   # numbers churn; bound it
                self._cache.clear()
                self._cache[key] = img
        return img

    def _blit(self, screen, s, font, col, x, y, right=False, center=False):
        img = self._text(s, font, col)
        if right:
            x -= img.get_width()
        elif center:
            x -= img.get_width() // 2
        screen.blit(img, (x, y))
        return img.get_width()

    def _panel(self, screen, x, y, w, h):
        pygame.draw.rect(screen, C_HUD_BG, (x, y, w, h))
        pygame.draw.rect(screen, C_HUD_LINE, (x, y, w, h), 1)

    def _meter(self, screen, x, y, w, h, frac, col, back=(22, 27, 36)):
        pygame.draw.rect(screen, back, (x, y, w, h))
        f = 0.0 if frac < 0.0 else (1.0 if frac > 1.0 else frac)
        if f > 0.0:
            pygame.draw.rect(screen, col, (x, y, max(1, int(w * f)), h))
        pygame.draw.rect(screen, C_HUD_LINE, (x, y, w, h), 1)

    # ------------------------------------------------------------------ blocks
    def _status(self, screen, sim):
        p = sim.player
        x, y = PAD, PAD
        self._panel(screen, x, y, BAR_W + 24, 132)
        x += 12
        y += 10

        self._blit(screen, "INTEGRITY", self.f_small, C_HUD_LINE, x, y)
        self._blit(screen, "%d" % int(p.hp + 0.5), self.f_small, C_HP,
                   x + BAR_W, y, right=True)
        y += 18
        hp_col = C_HP if p.hp > PLAYER_HP * 0.3 else C_RED
        self._meter(screen, x, y, BAR_W, 11, p.hp / PLAYER_HP, hp_col)
        y += 19

        ready = p.dash_cd <= 0.0
        self._blit(screen, "DASH READY" if ready else "DASH", self.f_small,
                   C_CYAN if ready else C_HUD_LINE, x, y)
        y += 17
        frac = 1.0 if ready else 1.0 - p.dash_cd / DASH_COOLDOWN
        self._meter(screen, x, y, BAR_W, 6, frac,
                    C_CYAN if ready else (40, 92, 112))
        y += 16

        self._blit(screen, "DAMAGE DEALT", self.f_small, C_HUD_LINE, x, y)
        y += 3
        self._blit(screen, "%d" % int(p.damage_dealt), self.f_big, C_AMBER,
                   x + BAR_W, y, right=True)

    def _loot(self, screen, sim):
        p = sim.player
        y = PAD + 140
        self._panel(screen, PAD, y, BAR_W + 24, 30)
        x = PAD + 12
        pygame.draw.circle(screen, C_CYAN, (x + 5, y + 15), 5)
        self._blit(screen, "%d" % p.plasma, self.f_mid, C_WHITE, x + 17, y + 6)
        x += 84
        pygame.draw.polygon(screen, C_AMBER, [(x + 5, y + 8), (x + 12, y + 15),
                                              (x + 5, y + 22), (x - 2, y + 15)])
        self._blit(screen, "%d" % p.cores, self.f_mid, C_WHITE, x + 20, y + 6)
        self._blit(screen, "KILLS %d" % p.kills, self.f_small, C_HUD_LINE,
                   PAD + BAR_W + 12, y + 9, right=True)

    def _minimap(self, screen, sim, cam):
        mx, my = self.mm_x, self.mm_y
        self._panel(screen, mx - 5, my - 5, self.mm_w + 10, self.mm_h + 28)
        screen.blit(self.minimap, (mx, my))

        for it in sim.pickups:                           # loot as faint specks
            if not it.is_plasma:
                screen.set_at((mx + int(it.x) // TILE, my + int(it.y) // TILE),
                              C_AMBER)
        for e in sim.enemies:
            ex = mx + int(e.x) // TILE
            ey = my + int(e.y) // TILE
            pygame.draw.rect(screen, C_RED, (ex - 1, ey - 1, 3, 3))

        vx = mx + cam.ox // TILE
        vy = my + cam.oy // TILE
        pygame.draw.rect(screen, (120, 140, 170),
                         (vx, vy, WINDOW_W // TILE, WINDOW_H // TILE), 1)

        px = mx + int(sim.player.x) // TILE
        py = my + int(sim.player.y) // TILE
        pygame.draw.line(screen, C_WHITE, (px - 3, py), (px + 3, py))
        pygame.draw.line(screen, C_WHITE, (px, py - 3), (px, py + 3))
        pygame.draw.circle(screen, C_CYAN, (px, py), 2)

        self._blit(screen, "SECTOR MAP", self.f_small, C_HUD_LINE,
                   mx, my + self.mm_h + 4)
        self._blit(screen, "%d,%d" % (int(sim.player.x) // TILE,
                                      int(sim.player.y) // TILE),
                   self.f_small, C_HUD_LINE, mx + self.mm_w,
                   my + self.mm_h + 4, right=True)

    def _hostiles(self, screen, sim):
        left = sim.hostiles_left
        total = sim.hostiles_at_start
        w = 300
        x = (WINDOW_W - w) // 2
        y = WINDOW_H - 46
        self._panel(screen, x - 12, y - 8, w + 24, 40)
        self._blit(screen, "HOSTILES", self.f_small, C_HUD_LINE, x, y)
        self._blit(screen, "%d / %d" % (left, total), self.f_small,
                   C_RED if left else C_HP, x + w, y, right=True)
        cleared = 1.0 - (left / total if total else 0.0)
        self._meter(screen, x, y + 17, w, 7, cleared, C_AMBER)

    def _safe_zone(self, screen, sim):
        if not sim.world.in_village(sim.player.x, sim.player.y):
            return
        img = self._text("VILLAGE  -  SAFE ZONE", self.f_mid, C_AMBER)
        x = (WINDOW_W - img.get_width()) // 2
        y = WINDOW_H - 84
        self._panel(screen, x - 14, y - 6, img.get_width() + 28,
                    img.get_height() + 12)
        screen.blit(img, (x, y))

    def _banner(self, screen, sim, paused):
        p = sim.player
        if p.alive and sim.hostiles_left > 0 and not paused:
            return
        if not p.alive:
            head, sub, col = "SYSTEMS DOWN", "R  restart", C_RED
        elif sim.hostiles_left == 0:
            head = "TERRITORY CLEARED"
            sub = "%d damage dealt  -  %d cores recovered" % (
                int(p.damage_dealt), p.cores)
            col = C_AMBER
        else:
            head, sub, col = "PAUSED", "ESC  resume", C_CYAN
        h = self._text(head, self.f_huge, col)
        s = self._text(sub, self.f_mid, C_WHITE)
        w = max(h.get_width(), s.get_width()) + 80
        x = (WINDOW_W - w) // 2
        y = WINDOW_H // 2 - 70
        self._panel(screen, x, y, w, 130)
        screen.blit(h, ((WINDOW_W - h.get_width()) // 2, y + 26))
        screen.blit(s, ((WINDOW_W - s.get_width()) // 2, y + 88))

    def _debug(self, screen, sim, cam, renderer, particles):
        p = sim.player
        lines = (
            "fps %5.1f   step %4.2fms   draw %4.2fms" % (self.fps, self.step_ms,
                                                         self.draw_ms),
            "pos %7.1f %7.1f   vel %6.1f %6.1f" % (p.x, p.y, p.vx, p.vy),
            "cam %5d %5d   shake %4.2f" % (cam.ox, cam.oy, cam.shake),
            "enemies %3d   bolts %3d   loot %3d   parts %4d" % (
                len(sim.enemies), len(sim.bolts), len(sim.pickups),
                len(particles)),
            "chunks %2d drawn / %3d cached" % (renderer.chunk_blits,
                                               renderer.tiles.cached),
            "elapsed %6.1fs   seed %d" % (sim.elapsed, sim.seed),
        )
        w, y = 430, PAD
        self._panel(screen, self.mm_x - w - 12, y, w, 20 * len(lines) + 14)
        for i, ln in enumerate(lines):
            self._blit(screen, ln, self.f_small, C_MAGENTA,
                       self.mm_x - w, y + 9 + i * 20)

    def _hint(self, screen, sim):
        if sim.elapsed > 14.0:                   # fades out once you are playing
            return
        self._blit(screen, "WASD move   MOUSE aim   LMB fire   SPACE dash",
                   self.f_small, (88, 104, 128), PAD, WINDOW_H - 52)
        self._blit(screen, "F1 debug   ESC pause   R restart   Q quit",
                   self.f_small, (88, 104, 128), PAD, WINDOW_H - 34)

    # -------------------------------------------------------------------- main
    def draw(self, screen, sim, cam, renderer, particles, paused=False):
        self._status(screen, sim)
        self._loot(screen, sim)
        self._minimap(screen, sim, cam)
        self._hostiles(screen, sim)
        self._safe_zone(screen, sim)
        self._hint(screen, sim)
        if self.debug:
            self._debug(screen, sim, cam, renderer, particles)
        self._banner(screen, sim, paused)

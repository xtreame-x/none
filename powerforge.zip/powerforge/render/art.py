"""Procedural tile art. The game ships with zero image files -- every texture
is generated once at startup from the palette in settings.py.

That keeps the repo tiny, makes the whole look retunable from one place, and
means there is nothing to re-author when this is ported to C++/SDL.
"""
import math
import random

import pygame

from settings import (TILE, TILE_VARIANTS, T_COUNT, T_VOID, T_FLOOR,
                      T_FLOOR_ALT, T_WALL, T_BRIDGE, T_VILLAGE, T_CONDUIT,
                      C_VOID, C_VOID_SPECK, C_FLOOR, C_FLOOR_EDGE, C_FLOOR_ALT,
                      C_WALL_TOP, C_WALL_SIDE, C_BRIDGE, C_VILLAGE,
                      C_VILLAGE_EDGE, C_CYAN, C_AMBER)

TILES = []            # TILES[tile_id][variant] -> Surface
_GLOWS = {}


def _clamp8(v):
    return 0 if v < 0 else (255 if v > 255 else v)


def _grain(surf, rng, count, spread):
    """Speckle a surface so flat fills don't look like flat fills."""
    for _ in range(count):
        x, y = rng.randrange(TILE), rng.randrange(TILE)
        d = rng.randint(-spread, spread)
        r, g, b = surf.get_at((x, y))[:3]
        surf.set_at((x, y), (_clamp8(r + d), _clamp8(g + d), _clamp8(b + d)))


def _plate(rng, base, edge, rivets=True):
    s = pygame.Surface((TILE, TILE))
    s.fill(base)
    _grain(s, rng, 110, 11)
    pygame.draw.line(s, edge, (0, 0), (TILE - 1, 0))
    pygame.draw.line(s, edge, (0, 0), (0, TILE - 1))
    if rivets:
        for p in ((3, 3), (TILE - 4, 3), (3, TILE - 4), (TILE - 4, TILE - 4)):
            s.set_at(p, edge)
    if rng.random() < 0.45:                          # occasional scratch
        x0, y0 = rng.randrange(TILE), rng.randrange(TILE)
        pygame.draw.line(s, edge, (x0, y0),
                         (x0 + rng.randint(-9, 9), y0 + rng.randint(-9, 9)))
    return s


def _void(rng):
    s = pygame.Surface((TILE, TILE))
    s.fill(C_VOID)
    for _ in range(rng.randint(1, 3)):               # far-off energy motes
        x, y = rng.randrange(TILE), rng.randrange(TILE)
        s.set_at((x, y), C_VOID_SPECK)
    return s


def _wall(rng):
    s = _plate(rng, C_WALL_SIDE, (58, 68, 86), rivets=False)
    pygame.draw.rect(s, C_WALL_TOP, (2, 2, TILE - 4, TILE - 8))
    _grain(s, rng, 70, 9)
    pygame.draw.line(s, (108, 120, 142), (2, 2), (TILE - 3, 2))
    pygame.draw.line(s, (108, 120, 142), (2, 2), (2, TILE - 7))
    pygame.draw.rect(s, (20, 24, 32), (2, TILE - 6, TILE - 4, 4))
    for i in range(3):                               # cooling vents
        y = 8 + i * 5
        pygame.draw.line(s, (30, 36, 48), (7, y), (TILE - 8, y))
    if rng.random() < 0.5:
        pygame.draw.line(s, (44, 116, 138), (7, 8), (TILE - 8, 8))
    return s


def _grate(rng):
    s = pygame.Surface((TILE, TILE))
    s.fill(C_BRIDGE)
    _grain(s, rng, 60, 8)
    for i in range(0, TILE, 5):                      # open catwalk mesh
        pygame.draw.line(s, (18, 22, 30), (i, 0), (i, TILE - 1))
        pygame.draw.line(s, (18, 22, 30), (0, i), (TILE - 1, i))
    pygame.draw.rect(s, (64, 76, 96), (0, 0, TILE, TILE), 1)
    return s


def _village(rng):
    s = _plate(rng, C_VILLAGE, C_VILLAGE_EDGE, rivets=False)
    c = TILE // 2
    pts = [(c + math.cos(math.tau * i / 6) * 11,
            c + math.sin(math.tau * i / 6) * 11) for i in range(6)]
    pygame.draw.polygon(s, (62, 56, 48), pts)
    pygame.draw.polygon(s, C_VILLAGE_EDGE, pts, 1)
    return s


def _conduit(rng):
    """A plus-shaped light strip, so conduits visually join in every direction."""
    s = _plate(rng, (30, 37, 48), (46, 56, 72), rivets=False)
    c = TILE // 2
    pygame.draw.rect(s, (28, 62, 78), (0, c - 3, TILE, 6))
    pygame.draw.rect(s, (28, 62, 78), (c - 3, 0, 6, TILE))
    pygame.draw.rect(s, (54, 138, 164), (0, c - 1, TILE, 2))
    pygame.draw.rect(s, (54, 138, 164), (c - 1, 0, 2, TILE))
    return s


def build_tiles():
    """Generate every tile id x variant. Call once, after the display exists."""
    global TILES
    makers = {
        T_VOID: _void,
        T_FLOOR: lambda r: _plate(r, C_FLOOR, C_FLOOR_EDGE),
        T_FLOOR_ALT: lambda r: _plate(r, C_FLOOR_ALT, (86, 88, 100)),
        T_WALL: _wall,
        T_BRIDGE: _grate,
        T_VILLAGE: _village,
        T_CONDUIT: _conduit,
    }
    TILES = []
    for tid in range(T_COUNT):
        make = makers[tid]
        variants = []
        for v in range(TILE_VARIANTS):
            rng = random.Random(tid * 977 + v * 31 + 5)
            variants.append(make(rng).convert())
        TILES.append(variants)


def glow(radius, color, peak=1.0):
    """Additive radial glow, cached. Blit with special_flags=BLEND_RGB_ADD."""
    key = (radius, color, round(peak, 2))
    s = _GLOWS.get(key)
    if s is not None:
        return s
    d = radius * 2
    s = pygame.Surface((d, d))
    for y in range(d):
        for x in range(d):
            dx, dy = x - radius + 0.5, y - radius + 0.5
            t = 1.0 - min(1.0, math.hypot(dx, dy) / radius)
            f = t * t * peak
            s.set_at((x, y), (_clamp8(int(color[0] * f)), _clamp8(int(color[1] * f)), _clamp8(int(color[2] * f))))
    s = s.convert()
    _GLOWS[key] = s
    return s


def build():
    build_tiles()
    glow(28, C_CYAN, 0.85)
    glow(20, C_AMBER, 0.8)

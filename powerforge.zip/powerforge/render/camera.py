"""Camera: smooth follow, velocity lead, world clamping, screen shake."""
import random

from settings import (WINDOW_W, WINDOW_H, WORLD_W, WORLD_H, CAM_LERP,
                      CAM_LOOKAHEAD, SHAKE_DECAY)
from sim.mathx import clamp


class Camera:
    def __init__(self):
        self.x = 0.0                 # top-left of the view, world pixels
        self.y = 0.0
        self.shake = 0.0
        self.ox = 0                  # integer offset actually used for blitting
        self.oy = 0

    def _target(self, e):
        # Lead the player slightly so you can see where you are going.
        tx = e.x + e.vx * CAM_LOOKAHEAD - WINDOW_W * 0.5
        ty = e.y + e.vy * CAM_LOOKAHEAD - WINDOW_H * 0.5
        return (clamp(tx, 0.0, WORLD_W - WINDOW_W),
                clamp(ty, 0.0, WORLD_H - WINDOW_H))

    def snap(self, e):
        self.x, self.y = self._target(e)
        self._bake()

    def update(self, e, dt):
        tx, ty = self._target(e)
        # Exponential smoothing, framerate independent.
        k = 1.0 - pow(2.718281828, -CAM_LERP * dt)
        self.x += (tx - self.x) * k
        self.y += (ty - self.y) * k
        if self.shake > 0.0:
            self.shake = max(0.0, self.shake - SHAKE_DECAY * dt * self.shake - 0.02)
        self._bake()

    def _bake(self):
        jx = jy = 0
        if self.shake > 0.01:
            a = self.shake * 9.0
            jx = int(random.uniform(-a, a))
            jy = int(random.uniform(-a, a))
        self.ox = int(self.x) - jx
        self.oy = int(self.y) - jy

    def kick(self, amount):
        self.shake = min(1.6, self.shake + amount)

    def to_screen(self, wx, wy):
        return int(wx) - self.ox, int(wy) - self.oy

    def to_world(self, sx, sy):
        return sx + self.ox, sy + self.oy

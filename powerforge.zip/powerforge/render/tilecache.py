"""Chunked tile renderer.

A 224x192 map is 43,008 tiles. Blitting the ~1,000 visible ones every frame
works but wastes most of the frame budget, so instead each 16x16 tile block is
drawn once into a cached 512x512 surface and the frame becomes ~12 big blits.

Island edges (rim light on the ground, shadow falling into the void) are baked
in here rather than into the tile textures, because they depend on neighbours.
"""
import pygame

from settings import (TILE, CHUNK, MAP_W, MAP_H, T_VOID, T_WALL, T_VILLAGE,
                      WINDOW_W, WINDOW_H)
from . import art

CHUNK_PX = CHUNK * TILE
RIM_COOL = (112, 134, 166)
RIM_WARM = (150, 122, 74)


class TileCache:
    def __init__(self, world):
        self.world = world
        self.chunks = {}
        self.cols = (MAP_W + CHUNK - 1) // CHUNK
        self.rows = (MAP_H + CHUNK - 1) // CHUNK
        self.shadow = pygame.Surface((TILE, 7), pygame.SRCALPHA)
        for i in range(7):
            a = int(150 * (1.0 - i / 7.0))
            pygame.draw.line(self.shadow, (0, 0, 0, a), (0, i), (TILE - 1, i))

    def _build(self, cx, cy):
        w = self.world
        surf = pygame.Surface((CHUNK_PX, CHUNK_PX))
        tx0, ty0 = cx * CHUNK, cy * CHUNK
        for j in range(CHUNK):
            ty = ty0 + j
            py = j * TILE
            for i in range(CHUNK):
                tx = tx0 + i
                px = i * TILE
                tid = w.tile(tx, ty)
                surf.blit(art.TILES[tid][w.variant(tx, ty)], (px, py))
                if tid == T_VOID:
                    if w.tile(tx, ty - 1) not in (T_VOID,):
                        surf.blit(self.shadow, (px, py))     # island casts down
                    continue
                if tid == T_WALL:
                    continue
                rim = RIM_WARM if tid == T_VILLAGE else RIM_COOL
                if w.tile(tx, ty - 1) == T_VOID:
                    pygame.draw.line(surf, rim, (px, py), (px + TILE - 1, py))
                if w.tile(tx, ty + 1) == T_VOID:
                    pygame.draw.line(surf, rim, (px, py + TILE - 1),
                                     (px + TILE - 1, py + TILE - 1))
                if w.tile(tx - 1, ty) == T_VOID:
                    pygame.draw.line(surf, rim, (px, py), (px, py + TILE - 1))
                if w.tile(tx + 1, ty) == T_VOID:
                    pygame.draw.line(surf, rim, (px + TILE - 1, py),
                                     (px + TILE - 1, py + TILE - 1))
        return surf.convert()

    def get(self, cx, cy):
        key = (cx, cy)
        s = self.chunks.get(key)
        if s is None:
            s = self._build(cx, cy)
            self.chunks[key] = s
        return s

    def draw(self, screen, cam):
        c0 = max(0, cam.ox // CHUNK_PX)
        r0 = max(0, cam.oy // CHUNK_PX)
        c1 = min(self.cols - 1, (cam.ox + WINDOW_W) // CHUNK_PX)
        r1 = min(self.rows - 1, (cam.oy + WINDOW_H) // CHUNK_PX)
        blits = 0
        for cy in range(r0, r1 + 1):
            for cx in range(c0, c1 + 1):
                screen.blit(self.get(cx, cy),
                            (cx * CHUNK_PX - cam.ox, cy * CHUNK_PX - cam.oy))
                blits += 1
        return blits

    def prewarm(self, cam):
        """Build the chunks around the start position so frame 1 isn't a hitch."""
        c = cam.ox // CHUNK_PX
        r = cam.oy // CHUNK_PX
        for cy in range(max(0, r - 1), min(self.rows, r + 3)):
            for cx in range(max(0, c - 1), min(self.cols, c + 4)):
                self.get(cx, cy)

    @property
    def cached(self):
        return len(self.chunks)

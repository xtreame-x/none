"""Draws the world. Reads simulation state, never modifies it."""
import math

import pygame

from settings import (WINDOW_W, WINDOW_H, C_CYAN, C_AMBER, C_RED, C_WHITE,
                      C_HP, P_PLASMA, TILE)
from sim.enemies import S_WINDUP, S_BURST
from . import art, sprites
from .tilecache import TileCache

MARGIN = 48


class Renderer:
    def __init__(self, screen, world):
        self.screen = screen
        self.tiles = TileCache(world)
        self.chunk_blits = 0

    def visible(self, cam, x, y, pad=MARGIN):
        sx, sy = x - cam.ox, y - cam.oy
        return -pad < sx < WINDOW_W + pad and -pad < sy < WINDOW_H + pad

    # ------------------------------------------------------------------- parts
    def _pickups(self, sim, cam, t):
        for it in sim.pickups:
            if not self.visible(cam, it.x, it.y):
                continue
            bob = math.sin(t * 3.0 + it.phase) * 3.0
            sx = int(it.x) - cam.ox
            sy = int(it.y + bob) - cam.oy
            if it.kind == P_PLASMA:
                g = art.glow(14, C_CYAN, 0.55)
                img = sprites.flat("plasma")
            else:
                g = art.glow(20, C_AMBER, 0.8)
                img = sprites.flat("core")
            self.screen.blit(g, (sx - g.get_width() // 2, sy - g.get_height() // 2),
                             special_flags=pygame.BLEND_RGB_ADD)
            self.screen.blit(img, (sx - img.get_width() // 2,
                                   sy - img.get_height() // 2))

    def _telegraph(self, e, cam):
        """Warning reticle + attack lane, so every hit is something you saw coming."""
        f = e.telegraph
        if f <= 0.0:
            return
        sx, sy = int(e.x) - cam.ox, int(e.y) - cam.oy
        bright = int(150 + 105 * f)
        col = (bright, int(bright * 0.26), int(bright * 0.22))
        ring = int(e.half + 4 + (1.0 - f) * 34)
        pygame.draw.circle(self.screen, col, (sx, sy), ring, 2)
        reach = e.d.burst_speed * e.d.burst_time if e.d.burst_speed > 0.0 else 260.0
        ex = sx + math.cos(e.angle) * reach
        ey = sy + math.sin(e.angle) * reach
        steps = 9
        for i in range(0, steps, 2):                     # dashed lane
            a0, a1 = i / steps, (i + 1) / steps
            pygame.draw.line(self.screen, col,
                             (sx + (ex - sx) * a0, sy + (ey - sy) * a0),
                             (sx + (ex - sx) * a1, sy + (ey - sy) * a1), 2)

    def _bar(self, x, y, w, frac, col):
        pygame.draw.rect(self.screen, (12, 14, 20), (x - 1, y - 1, w + 2, 5))
        pygame.draw.rect(self.screen, col, (x, y, int(w * frac), 3))

    def _enemies(self, sim, cam):
        for e in sim.enemies:
            if not self.visible(cam, e.x, e.y, 80):
                continue
            sx, sy = int(e.x) - cam.ox, int(e.y) - cam.oy
            self._telegraph(e, cam)
            if e.state == S_BURST:
                g = art.glow(28, C_RED, 0.5)
                self.screen.blit(g, (sx - 28, sy - 28),
                                 special_flags=pygame.BLEND_RGB_ADD)
            img = sprites.rotated(sprites.ENEMY_SPRITES[e.kind], e.angle)
            pos = (sx - img.get_width() // 2, sy - img.get_height() // 2)
            self.screen.blit(img, pos)
            if e.flash > 0.0:
                self.screen.blit(img, pos, special_flags=pygame.BLEND_RGB_ADD)
            if e.hp < e.hp_max:
                w = int(e.half * 2.6)
                self._bar(sx - w // 2, sy - int(e.half) - 12, w,
                          e.hp / e.hp_max, C_RED)

    def _player(self, sim, cam):
        p = sim.player
        sx, sy = int(p.x) - cam.ox, int(p.y) - cam.oy
        img = sprites.rotated("player", p.angle)
        if p.dashing:                                    # afterimages
            for k in (3, 2, 1):
                ax = sx - int(p.vx * 0.012 * k)
                ay = sy - int(p.vy * 0.012 * k)
                ghost = img.copy()
                ghost.set_alpha(40 * k)
                self.screen.blit(ghost, (ax - img.get_width() // 2,
                                         ay - img.get_height() // 2))
        g = art.glow(28, C_CYAN, 0.85 if not p.dashing else 1.4)
        self.screen.blit(g, (sx - 28, sy - 28), special_flags=pygame.BLEND_RGB_ADD)
        pos = (sx - img.get_width() // 2, sy - img.get_height() // 2)
        self.screen.blit(img, pos)
        if p.iframe > 0.0 and int(p.iframe * 24.0) % 2 == 0:
            self.screen.blit(img, pos, special_flags=pygame.BLEND_RGB_ADD)

    def _bolts(self, sim, cam):
        for b in sim.bolts:
            if not self.visible(cam, b.x, b.y):
                continue
            sx, sy = int(b.x) - cam.ox, int(b.y) - cam.oy
            col = C_CYAN if b.from_player else (226, 104, 255)
            g = art.glow(12, col, 0.7)
            self.screen.blit(g, (sx - 12, sy - 12),
                             special_flags=pygame.BLEND_RGB_ADD)
            img = sprites.rotated("bolt_p" if b.from_player else "bolt_e", b.angle)
            self.screen.blit(img, (sx - img.get_width() // 2,
                                   sy - img.get_height() // 2))

    # -------------------------------------------------------------------- main
    def draw(self, sim, cam, particles):
        self.chunk_blits = self.tiles.draw(self.screen, cam)
        self._pickups(sim, cam, sim.elapsed)
        self._enemies(sim, cam)
        self._bolts(sim, cam)
        self._player(sim, cam)
        particles.draw(self.screen, cam)

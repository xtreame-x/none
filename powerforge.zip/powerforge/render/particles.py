"""Particles and screen shake, driven entirely by the event list the simulation
hands back each step.

The simulation never knows these exist -- it just reports "a bolt struck here"
and this layer decides what that looks like. Keeps feel-tuning out of gameplay.
"""
import math
import random

import pygame

from settings import (C_CYAN, C_AMBER, C_RED, C_MAGENTA, C_WHITE, WINDOW_W,
                      WINDOW_H, P_PLASMA)
from sim.sim import (EV_SPARK, EV_KILL, EV_DASH, EV_PICKUP, EV_HURT, EV_SHOT,
                     EV_ENEMY_SHOT)

# particle layout: [x, y, vx, vy, life, life0, radius, r, g, b]
DRAG = 2.4


class Particles:
    def __init__(self):
        self.items = []

    def burst(self, x, y, n, color, speed, radius=3, life=0.4,
              angle=None, spread=math.pi):
        for _ in range(n):
            a = random.uniform(0.0, math.tau) if angle is None else \
                angle + random.uniform(-spread, spread)
            v = speed * random.uniform(0.35, 1.0)
            lf = life * random.uniform(0.6, 1.25)
            self.items.append([x, y, math.cos(a) * v, math.sin(a) * v,
                               lf, lf, radius * random.uniform(0.6, 1.2),
                               color[0], color[1], color[2]])

    def update(self, dt):
        keep = []
        damp = 1.0 - DRAG * dt
        if damp < 0.0:
            damp = 0.0
        for p in self.items:
            p[4] -= dt
            if p[4] <= 0.0:
                continue
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[2] *= damp
            p[3] *= damp
            keep.append(p)
        self.items = keep

    def draw(self, screen, cam):
        for p in self.items:
            sx = int(p[0]) - cam.ox
            sy = int(p[1]) - cam.oy
            if sx < -8 or sy < -8 or sx > WINDOW_W + 8 or sy > WINDOW_H + 8:
                continue
            f = p[4] / p[5]
            r = max(1, int(p[6] * (0.4 + 0.6 * f)))
            col = (int(p[7] * f), int(p[8] * f), int(p[9] * f))
            pygame.draw.circle(screen, col, (sx, sy), r, 0)

    # ------------------------------------------------------------------ events
    def feed(self, events, cam):
        """Turn one step's simulation events into visuals and camera kicks."""
        for kind, x, y, extra in events:
            if kind == EV_SPARK:
                self.burst(x, y, 6, C_AMBER, 190.0, 2.4, 0.22,
                           angle=extra, spread=0.9)
            elif kind == EV_KILL:
                self.burst(x, y, 22, C_AMBER, 260.0, 3.4, 0.55)
                self.burst(x, y, 10, C_WHITE, 150.0, 2.2, 0.30)
                cam.kick(0.30 if extra == 2 else 0.16)
            elif kind == EV_DASH:
                self.burst(x, y, 12, C_CYAN, 120.0, 2.6, 0.30)
                cam.kick(0.05)
            elif kind == EV_PICKUP:
                col = C_CYAN if extra == P_PLASMA else C_AMBER
                self.burst(x, y, 9, col, 130.0, 2.2, 0.34)
            elif kind == EV_HURT:
                self.burst(x, y, 16, C_RED, 240.0, 3.0, 0.45)
                cam.kick(0.55)
            elif kind == EV_SHOT:
                self.burst(x, y, 4, C_CYAN, 150.0, 2.0, 0.14,
                           angle=extra, spread=0.5)
            elif kind == EV_ENEMY_SHOT:
                self.burst(x, y, 3, C_MAGENTA, 140.0, 2.0, 0.16,
                           angle=extra, spread=0.5)

    def __len__(self):
        return len(self.items)

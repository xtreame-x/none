"""Procedural entity sprites, pre-rotated into angle buckets at startup.

Rotating a surface every frame is wasteful and looks unstable; baking N facings
once is cheap, stable, and how you would do it with a texture atlas in C++.
All sprites are authored pointing along +X (screen right).
"""
import math

import pygame

from settings import (C_CYAN, C_AMBER, C_RED, C_MAGENTA, C_WHITE)

ANGLE_BUCKETS = 24
_ROT = {}
_FLAT = {}


def _surf(size):
    return pygame.Surface((size, size), pygame.SRCALPHA)


def _poly(n, cx, cy, r, phase=0.0):
    return [(cx + math.cos(math.tau * i / n + phase) * r,
             cy + math.sin(math.tau * i / n + phase) * r) for i in range(n)]


def _player():
    s = _surf(40)
    c = 20
    pygame.draw.polygon(s, (150, 168, 198), [(c + 4, c - 6), (c + 21, c - 4),
                                             (c + 21, c + 4), (c + 4, c + 6)])
    pygame.draw.line(s, (86, 100, 126), (c + 5, c), (c + 19, c))
    pygame.draw.polygon(s, C_CYAN, [(c + 16, c - 4), (c + 23, c),
                                    (c + 16, c + 4)])
    body = _poly(6, c, c, 13)
    pygame.draw.polygon(s, (74, 92, 122), body)
    pygame.draw.polygon(s, (52, 66, 90), _poly(6, c, c, 9))
    pygame.draw.polygon(s, C_CYAN, body, 3)
    for sy in (-1, 1):                                  # shoulder pods
        pygame.draw.rect(s, (96, 114, 144), (c - 10, c + sy * 9 - 3, 12, 7))
        pygame.draw.rect(s, (148, 168, 198), (c - 10, c + sy * 9 - 3, 12, 7), 1)
    pygame.draw.circle(s, (30, 104, 132), (c, c), 6)
    pygame.draw.circle(s, C_CYAN, (c, c), 4)
    pygame.draw.circle(s, C_WHITE, (c - 1, c - 1), 2)
    return s


def _crawler():
    s = _surf(30)
    c = 15
    for sy in (-1, 1):                                  # scrabbling legs
        for lx, ly in ((-6, 8), (2, 9), (8, 6)):
            pygame.draw.line(s, (128, 60, 54), (c, c),
                             (c + lx, c + sy * ly), 2)
    pygame.draw.polygon(s, (74, 34, 34),
                        [(c + 11, c), (c - 6, c - 8), (c - 9, c), (c - 6, c + 8)])
    pygame.draw.polygon(s, C_RED,
                        [(c + 11, c), (c - 6, c - 8), (c - 9, c), (c - 6, c + 8)], 2)
    pygame.draw.circle(s, C_RED, (c + 4, c), 3)
    pygame.draw.circle(s, C_WHITE, (c + 4, c), 1)
    return s


def _drone():
    s = _surf(34)
    c = 17
    pygame.draw.circle(s, (78, 40, 96), (c, c), 12)
    pygame.draw.circle(s, C_MAGENTA, (c, c), 12, 2)
    for sy in (-1, 1):                                  # thruster fins
        pygame.draw.polygon(s, (58, 30, 72),
                            [(c - 4, c + sy * 8), (c - 13, c + sy * 13),
                             (c - 9, c + sy * 5)])
    pygame.draw.polygon(s, (44, 22, 56),
                        [(c + 12, c), (c, c - 8), (c - 8, c), (c, c + 8)])
    pygame.draw.polygon(s, C_MAGENTA,
                        [(c + 12, c), (c, c - 8), (c - 8, c), (c, c + 8)], 1)
    pygame.draw.circle(s, C_MAGENTA, (c + 4, c), 4)
    pygame.draw.circle(s, C_WHITE, (c + 4, c), 2)
    return s


def _breaker():
    s = _surf(54)
    c = 27
    body = _poly(6, c, c, 20)
    pygame.draw.polygon(s, (62, 48, 30), body)
    pygame.draw.polygon(s, C_AMBER, body, 3)
    pygame.draw.polygon(s, (96, 74, 44),                # ram plate
                        [(c + 10, c - 13), (c + 21, c - 6),
                         (c + 21, c + 6), (c + 10, c + 13)])
    pygame.draw.polygon(s, C_AMBER,
                        [(c + 10, c - 13), (c + 21, c - 6),
                         (c + 21, c + 6), (c + 10, c + 13)], 2)
    for sy in (-1, 1):
        pygame.draw.rect(s, (44, 34, 22), (c - 16, c + sy * 11 - 4, 14, 8))
        pygame.draw.rect(s, (120, 92, 54), (c - 16, c + sy * 11 - 4, 14, 8), 1)
    pygame.draw.circle(s, (26, 20, 14), (c - 2, c), 8)
    pygame.draw.circle(s, C_AMBER, (c - 2, c), 8, 2)
    pygame.draw.circle(s, C_WHITE, (c - 2, c), 3)
    return s


def _bolt(color, length=14, width=6):
    s = pygame.Surface((length, width), pygame.SRCALPHA)
    pygame.draw.ellipse(s, color, (0, 0, length, width))
    pygame.draw.ellipse(s, C_WHITE, (length // 3, width // 2 - 1,
                                     length // 2, 2))
    return s


def _plasma():
    s = _surf(18)
    pygame.draw.circle(s, (24, 82, 104), (9, 9), 7)
    pygame.draw.circle(s, C_CYAN, (9, 9), 5)
    pygame.draw.circle(s, C_WHITE, (8, 8), 2)
    return s


def _core():
    s = _surf(20)
    pygame.draw.polygon(s, (92, 62, 22), [(10, 1), (19, 10), (10, 19), (1, 10)])
    pygame.draw.polygon(s, C_AMBER, [(10, 1), (19, 10), (10, 19), (1, 10)], 2)
    pygame.draw.circle(s, C_WHITE, (10, 10), 2)
    return s


def _register_rotating(name, surf):
    frames = []
    for i in range(ANGLE_BUCKETS):
        deg = -360.0 * i / ANGLE_BUCKETS       # screen y is down, so negate
        frames.append(pygame.transform.rotate(surf.convert_alpha(), deg))
    _ROT[name] = frames


def build():
    _register_rotating("player", _player())
    _register_rotating("crawler", _crawler())
    _register_rotating("drone", _drone())
    _register_rotating("breaker", _breaker())
    _register_rotating("bolt_p", _bolt(C_CYAN))
    _register_rotating("bolt_e", _bolt(C_MAGENTA, 15, 8))
    _FLAT["plasma"] = _plasma().convert_alpha()
    _FLAT["core"] = _core().convert_alpha()


ENEMY_SPRITES = ("crawler", "drone", "breaker")


def rotated(name, angle):
    frames = _ROT[name]
    i = int((angle % math.tau) / math.tau * ANGLE_BUCKETS + 0.5) % ANGLE_BUCKETS
    return frames[i]


def flat(name):
    return _FLAT[name]

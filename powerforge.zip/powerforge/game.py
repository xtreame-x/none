"""Game shell: window, input mapping, fixed-timestep loop.

Everything device-specific stops here. `read_input` collapses keyboard and mouse
into an InputState, and `advance()` runs one frame from an InputState -- which is
why a scripted bot can drive the real game loop with no display attached.
"""
import os
import time

import pygame

from settings import (WINDOW_W, WINDOW_H, TARGET_FPS, FIXED_DT,
                      MAX_STEPS_PER_FRAME, WORLD_SEED)
from sim.sim import Simulation
from sim.inputs import InputState, NEUTRAL
from render import art, sprites
from render.camera import Camera
from render.renderer import Renderer
from render.hud import Hud
from render.particles import Particles

K_LEFT_SET = (pygame.K_a, pygame.K_LEFT)
K_RIGHT_SET = (pygame.K_d, pygame.K_RIGHT)
K_UP_SET = (pygame.K_w, pygame.K_UP)
K_DOWN_SET = (pygame.K_s, pygame.K_DOWN)
INV_SQRT2 = 0.7071067811865476


def _axis(keys, neg, pos):
    v = 0.0
    for k in neg:
        if keys[k]:
            v -= 1.0
            break
    for k in pos:
        if keys[k]:
            v += 1.0
            break
    return v


def read_input(cam, player):
    keys = pygame.key.get_pressed()
    mx = _axis(keys, K_LEFT_SET, K_RIGHT_SET)
    my = _axis(keys, K_UP_SET, K_DOWN_SET)
    if mx != 0.0 and my != 0.0:
        mx *= INV_SQRT2
        my *= INV_SQRT2
    wx, wy = cam.to_world(*pygame.mouse.get_pos())
    ax, ay = wx - player.x, wy - player.y
    n = (ax * ax + ay * ay) ** 0.5
    if n > 1e-6:
        ax, ay = ax / n, ay / n
    else:
        ax, ay = 1.0, 0.0
    btn = pygame.mouse.get_pressed()
    return InputState(mx, my, ax, ay,
                      btn[0] or keys[pygame.K_j],
                      keys[pygame.K_SPACE] or btn[2])


class Game:
    def __init__(self, seed=WORLD_SEED, headless=False):
        if headless:
            os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        pygame.display.set_caption("Power Forge  --  Alpha")
        art.build()                      # needs a display for .convert()
        sprites.build()
        self.clock = pygame.time.Clock()
        self.headless = headless
        self.running = True
        self.paused = False
        self.acc = 0.0
        self.frames = 0
        self.hud = None
        self._hud_seed = None
        self.new_run(seed)

    # ----------------------------------------------------------------- setup
    def new_run(self, seed):
        self.sim = Simulation(seed)
        self.cam = Camera()
        self.cam.snap(self.sim.player)
        self.particles = Particles()
        self.renderer = Renderer(self.screen, self.sim.world)
        self.renderer.tiles.prewarm(self.cam)
        if self.hud is None or self._hud_seed != seed:
            self.hud = Hud(self.sim.world)       # minimap bake, so reuse it
            self._hud_seed = seed
        self.acc = 0.0

    # ---------------------------------------------------------------- events
    def pump(self):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                self.running = False
            elif ev.type == pygame.KEYDOWN:
                self._key(ev.key)

    def _key(self, key):
        if key == pygame.K_ESCAPE:
            self.paused = not self.paused
        elif key == pygame.K_F1:
            self.hud.debug = not self.hud.debug
        elif key == pygame.K_F11:
            pygame.display.toggle_fullscreen()
        elif key == pygame.K_r:
            self.new_run(self.sim.seed)
        elif key == pygame.K_q:
            self.running = False

    # ------------------------------------------------------------------ frame
    def advance(self, inp, dt):
        """One frame: fixed-step the sim, then draw. Input is already resolved."""
        t0 = time.perf_counter()
        if not self.paused and self.sim.player.alive:
            self.acc += dt
            steps = 0
            while self.acc >= FIXED_DT and steps < MAX_STEPS_PER_FRAME:
                self.particles.feed(self.sim.step(inp, FIXED_DT), self.cam)
                self.acc -= FIXED_DT
                steps += 1
            if steps == MAX_STEPS_PER_FRAME:
                self.acc = 0.0                   # we are behind; drop the debt
            self.particles.update(dt)
        self.cam.update(self.sim.player, dt)
        t1 = time.perf_counter()

        self.renderer.draw(self.sim, self.cam, self.particles)
        self.hud.draw(self.screen, self.sim, self.cam, self.renderer,
                      self.particles, self.paused)
        t2 = time.perf_counter()

        self.hud.step_ms = (t1 - t0) * 1000.0
        self.hud.draw_ms = (t2 - t1) * 1000.0
        self.hud.fps = self.clock.get_fps()
        pygame.display.flip()
        self.frames += 1

    def frame(self):
        dt = self.clock.tick(TARGET_FPS) / 1000.0
        if dt > 0.1:
            dt = 0.1                             # after a stall, do not teleport
        self.pump()
        alive = self.sim.player.alive and not self.paused
        inp = read_input(self.cam, self.sim.player) if alive else NEUTRAL
        self.advance(inp, dt)

    def run(self):
        while self.running:
            self.frame()
        pygame.quit()

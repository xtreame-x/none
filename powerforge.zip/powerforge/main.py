"""Power Forge -- alpha. Entry point.

    python main.py [--seed N] [--headless]

Controls: WASD move, mouse aim, left mouse fire, space dash, F1 debug,
F11 fullscreen, ESC pause, R restart, Q quit.
"""
import sys

from settings import WORLD_SEED


def parse(argv):
    seed, headless = WORLD_SEED, False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--seed" and i + 1 < len(argv):
            seed = int(argv[i + 1])
            i += 1
        elif a == "--headless":
            headless = True
        elif a in ("-h", "--help"):
            print(__doc__)
            return None, None
        i += 1
    return seed, headless


def main():
    seed, headless = parse(sys.argv[1:])
    if seed is None:
        return 0
    try:
        from game import Game
    except ImportError as exc:
        print("Could not start: %s" % exc)
        print("Power Forge needs pygame:  pip install pygame")
        return 1
    Game(seed=seed, headless=headless).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())

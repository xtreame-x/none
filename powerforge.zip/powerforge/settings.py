"""POWER FORGE -- Alpha 0.1  |  central tuning table.

Pure data. No logic, no game imports. This is the one file you edit to change
how the game feels, and the file that becomes `config.h` when this is
rewritten in C++.
"""
from typing import NamedTuple

# ==================================================================== DISPLAY
WINDOW_W = 1280
WINDOW_H = 720
WINDOW_TITLE = "POWER FORGE  --  Alpha 0.1"
TARGET_FPS = 60
FIXED_DT = 1.0 / 60.0          # simulation step, seconds (never varies)
MAX_STEPS_PER_FRAME = 5        # clamp so a lag spike can't death-spiral

# ==================================================================== WORLD
TILE = 32                      # pixels per tile
MAP_W = 224                    # tiles across
MAP_H = 192                    # tiles down
WORLD_W = MAP_W * TILE         # 7168 px  (~5.6 screens wide)
WORLD_H = MAP_H * TILE         # 6144 px  (~8.5 screens tall)
RING_RX = 76                   # outer island ring, tiles
RING_RY = 66
OUTER_ISLANDS = 6
MID_ISLANDS = 6                # placed opportunistically wherever they fit
CHUNK = 16                     # tiles per cached render chunk
WORLD_SEED = 20260904

# --- tile ids (index into SOLID / the art tables) ---------------------------
T_VOID = 0                     # the chasm below the floating islands
T_FLOOR = 1                    # standard metal plating
T_FLOOR_ALT = 2                # worn plating variant
T_WALL = 3                     # solid machinery block
T_BRIDGE = 4                   # catwalk between islands
T_VILLAGE = 5                  # village pad (safe zone)
T_CONDUIT = 6                  # glowing energy strip, walkable
T_COUNT = 7
SOLID = (True, False, False, True, False, False, False)   # indexed by tile id
TILE_VARIANTS = 4              # cosmetic variants generated per tile id

VILLAGE_RADIUS = 26            # tiles; also the safe-zone radius

# ==================================================================== PLAYER
PLAYER_HALF = 11.0             # half-width of the collision box, px
PLAYER_SPEED = 250.0           # px/sec top speed
PLAYER_ACCEL = 2400.0          # px/sec^2 while input held
PLAYER_FRICTION = 2200.0       # px/sec^2 while input released
PLAYER_HP = 100.0
PLAYER_IFRAME = 0.65           # invulnerable seconds after taking a hit
PLAYER_REGEN_DELAY = 6.0       # seconds out of combat before regen starts
PLAYER_REGEN_RATE = 4.0        # hp/sec

DASH_SPEED = 640.0
DASH_TIME = 0.16               # seconds of dash movement
DASH_COOLDOWN = 0.65           # seconds before you can dash again
DASH_IFRAME = 0.22             # invulnerable window covering the dash

# ==================================================================== WEAPON
BOLT_SPEED = 780.0
BOLT_DAMAGE = 14.0
BOLT_LIFE = 0.85               # seconds before it fizzles
BOLT_HALF = 4.0
FIRE_COOLDOWN = 0.15
BOLT_SPREAD = 0.025            # radians of random spread

ENEMY_BOLT_SPEED = 330.0
ENEMY_BOLT_LIFE = 2.4
ENEMY_BOLT_HALF = 5.0

# ==================================================================== ENEMIES
class EnemyDef(NamedTuple):
    """One enemy archetype. Maps directly onto a C++ POD struct."""
    name: str
    hp: float
    half: float                # collision half-extent
    speed: float
    accel: float
    aggro: float               # distance at which it notices you
    act_range: float           # distance at which it commits to its attack
    windup: float              # telegraph time before the attack lands
    burst_speed: float         # lunge / charge speed (0 = ranged attacker)
    burst_time: float
    burst_turn: float          # rad/sec the lunge may curve toward you
    recover: float             # stun after attacking
    damage: float
    ranged: bool
    value: int                 # score / salvage worth


BURST_LEAD = 0.8               # how much a charger leads your current velocity

# Fast, fragile, hunts in packs. Slightly FASTER than the player on purpose --
# a chaser you can outrun is just scenery. You have to dash or kill it.
CRAWLER = EnemyDef("Scrap Crawler", 34.0, 10.0, 278.0, 1600.0, 440.0, 40.0,
                   0.26, 560.0, 0.20, 3.0, 0.50, 9.0, False, 1)
# Hovers at range, strafes, fires plasma. Punishes standing still.
DRONE = EnemyDef("Sentry Drone", 48.0, 12.0, 145.0, 900.0, 580.0, 300.0,
                 0.45, 0.0, 0.0, 0.0, 1.05, 11.0, True, 2)
# Slow armoured bruiser. Long telegraph, then a charge that overshoots you --
# it curves a little, so you dodge it by timing, not by walking sideways.
BREAKER = EnemyDef("Breaker", 155.0, 18.0, 80.0, 620.0, 540.0, 270.0,
                   0.85, 560.0, 0.60, 1.10, 1.10, 22.0, False, 5)
ENEMY_DEFS = (CRAWLER, DRONE, BREAKER)
E_CRAWLER, E_DRONE, E_BREAKER = 0, 1, 2

DRONE_BAND_MIN = 210.0         # drone tries to stay inside this distance band
DRONE_BAND_MAX = 340.0
DRONE_STRAFE = 0.75            # sideways drift while in band

KNOCKBACK = 130.0              # px/sec applied to an enemy per bolt hit

# ==================================================================== PICKUPS
P_PLASMA = 0
P_CORE = 1
PICKUP_HALF = 8.0
PICKUP_MAGNET = 46.0           # auto-collect radius
PLASMA_COUNT = 44
CORE_COUNT = 9

# ==================================================================== SPAWNS
CRAWLERS_PER_OUTER = 2
DRONES_PER_OUTER = 1
BREAKER_ISLANDS = 3            # how many outer islands get a Breaker
CRAWLERS_PER_MID = 1

# ==================================================================== CAMERA
CAM_LERP = 9.0                 # higher = snappier follow
CAM_LOOKAHEAD = 0.10           # fraction of velocity to lead the player by
SHAKE_DECAY = 7.0

# ==================================================================== PALETTE
# (r, g, b) -- the world is dark metal, hazard amber and cyan energy.
C_VOID = (6, 8, 14)
C_VOID_SPECK = (30, 44, 70)
C_FLOOR = (46, 55, 72)
C_FLOOR_EDGE = (72, 86, 110)
C_FLOOR_ALT = (56, 61, 74)
C_WALL_TOP = (80, 91, 111)
C_WALL_SIDE = (40, 47, 61)
C_BRIDGE = (38, 46, 60)
C_VILLAGE = (58, 52, 45)
C_VILLAGE_EDGE = (104, 86, 56)
C_CYAN = (90, 226, 255)
C_AMBER = (255, 176, 64)
C_RED = (255, 86, 78)
C_MAGENTA = (226, 104, 255)
C_WHITE = (238, 246, 255)
C_HUD_BG = (10, 13, 20)
C_HUD_LINE = (58, 74, 98)
C_HP = (86, 230, 140)

"""The tile world: queries, swept AABB collision, line of sight.

No rendering, no pygame. The renderer reads `world.tiles` but never writes it.
"""
from settings import (MAP_W, MAP_H, TILE, SOLID, WORLD_SEED, TILE_VARIANTS,
                      VILLAGE_RADIUS)
from .worldgen import generate

EPS = 1e-4


class World:
    def __init__(self, seed=WORLD_SEED):
        self.data = generate(seed)
        self.tiles = self.data.tiles
        v = self.data.islands[0]
        self.village_x = (v.cx + 0.5) * TILE
        self.village_y = (v.cy + 0.5) * TILE
        self.village_r = (VILLAGE_RADIUS - 2) * TILE

    # ------------------------------------------------------------- queries
    def tile(self, tx, ty):
        if 0 <= tx < MAP_W and 0 <= ty < MAP_H:
            return self.tiles[ty * MAP_W + tx]
        return 0                                   # out of bounds reads as void

    def solid(self, tx, ty):
        if 0 <= tx < MAP_W and 0 <= ty < MAP_H:
            return SOLID[self.tiles[ty * MAP_W + tx]]
        return True                                # the map edge is a wall

    def solid_px(self, x, y):
        return self.solid(int(x // TILE), int(y // TILE))

    def variant(self, tx, ty):
        """Deterministic cosmetic variant index for a tile -- cheap hash, no storage."""
        h = (tx * 73856093) ^ (ty * 19349663)
        return (h >> 4) % TILE_VARIANTS

    def in_village(self, x, y):
        dx = x - self.village_x
        dy = y - self.village_y
        return dx * dx + dy * dy < self.village_r * self.village_r

    def line_blocked(self, x0, y0, x1, y1, step=14.0):
        """Coarse line of sight. Used by ranged enemies before they commit to a shot."""
        dx, dy = x1 - x0, y1 - y0
        n = int(max(abs(dx), abs(dy)) / step)
        if n <= 0:
            return False
        for i in range(1, n):
            t = i / n
            if self.solid_px(x0 + dx * t, y0 + dy * t):
                return True
        return False

    # ----------------------------------------------------------- collision
    def move_and_collide(self, e, dx, dy):
        """Move an entity by (dx, dy), resolving each axis against solid tiles.

        Axis-separated resolution: the classic tile-collision approach. It
        cannot tunnel as long as a single step is shorter than one tile, which
        the tuning in settings.py guarantees (fastest thing is ~13 px/step).

        Returns (hit_x, hit_y) so callers can cancel velocity or end a dash.
        """
        hx = hy = e.half
        hit_x = hit_y = False

        if dx != 0.0:
            e.x += dx
            top, bot = e.y - hy, e.y + hy - EPS
            ty0, ty1 = int(top // TILE), int(bot // TILE)
            if dx > 0.0:
                tx = int((e.x + hx - EPS) // TILE)
                for ty in range(ty0, ty1 + 1):
                    if self.solid(tx, ty):
                        e.x = tx * TILE - hx - EPS
                        hit_x = True
                        break
            else:
                tx = int((e.x - hx) // TILE)
                for ty in range(ty0, ty1 + 1):
                    if self.solid(tx, ty):
                        e.x = (tx + 1) * TILE + hx + EPS
                        hit_x = True
                        break

        if dy != 0.0:
            e.y += dy
            left, right = e.x - hx, e.x + hx - EPS
            tx0, tx1 = int(left // TILE), int(right // TILE)
            if dy > 0.0:
                ty = int((e.y + hy - EPS) // TILE)
                for tx in range(tx0, tx1 + 1):
                    if self.solid(tx, ty):
                        e.y = ty * TILE - hy - EPS
                        hit_y = True
                        break
            else:
                ty = int((e.y - hy) // TILE)
                for tx in range(tx0, tx1 + 1):
                    if self.solid(tx, ty):
                        e.y = (ty + 1) * TILE + hy + EPS
                        hit_y = True
                        break

        return hit_x, hit_y

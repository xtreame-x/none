"""Projectiles -- plasma bolts, fired by the player and by Sentry Drones."""
import math

from settings import (BOLT_SPEED, BOLT_DAMAGE, BOLT_LIFE, BOLT_HALF,
                      ENEMY_BOLT_SPEED, ENEMY_BOLT_LIFE, ENEMY_BOLT_HALF)


class Bolt:
    __slots__ = ("x", "y", "vx", "vy", "half", "life", "damage",
                 "from_player", "alive", "angle")

    def __init__(self, x, y, angle, speed, damage, life, half, from_player):
        self.x = float(x)
        self.y = float(y)
        self.angle = float(angle)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.half = half
        self.life = life
        self.damage = damage
        self.from_player = from_player
        self.alive = True

    def update(self, world, dt):
        """Advance one step. Returns True if it struck geometry this step."""
        self.life -= dt
        if self.life <= 0.0:
            self.alive = False
            return False
        self.x += self.vx * dt
        self.y += self.vy * dt
        if world.solid_px(self.x, self.y):
            self.alive = False
            return True
        return False


def player_bolt(x, y, angle):
    return Bolt(x, y, angle, BOLT_SPEED, BOLT_DAMAGE, BOLT_LIFE,
                BOLT_HALF, True)


def enemy_bolt(x, y, angle, damage):
    return Bolt(x, y, angle, ENEMY_BOLT_SPEED, damage, ENEMY_BOLT_LIFE,
                ENEMY_BOLT_HALF, False)

"""Builds the raid map: floating hexagonal islands linked by catwalks.

The centre island is the village (safe, no spawns) -- per the design doc the
village replaces the lobby. Everything outward from it is raid territory.

`generate(seed)` is deterministic: the same seed always produces the same map,
which makes bugs reproducible and lets the renderer cache freely.
"""
import math
import random
from typing import NamedTuple

from settings import (MAP_W, MAP_H, TILE, WORLD_SEED, VILLAGE_RADIUS,
                      RING_RX, RING_RY, OUTER_ISLANDS, MID_ISLANDS, SOLID,
                      T_FLOOR, T_FLOOR_ALT, T_WALL, T_VILLAGE, T_CONDUIT,
                      E_CRAWLER, E_DRONE, E_BREAKER, P_PLASMA, P_CORE,
                      CRAWLERS_PER_OUTER, DRONES_PER_OUTER, BREAKER_ISLANDS,
                      CRAWLERS_PER_MID, PLASMA_COUNT, CORE_COUNT)
from .mathx import TAU, dist, in_hex
from .mapbrush import (in_bounds, paint_hex, carve_bridge, scatter_patches,
                       scatter_walls, clear_walls, flood_reachable)

K_VILLAGE, K_MID, K_OUTER = 0, 1, 2


class Island(NamedTuple):
    cx: int
    cy: int
    r: int
    kind: int


class MapData(NamedTuple):
    tiles: bytearray                 # flat MAP_W * MAP_H array of tile ids
    islands: tuple
    spawn_x: float                   # player start, world pixels
    spawn_y: float
    enemies: tuple                   # (type_id, x, y)
    pickups: tuple                   # (kind, x, y)


def _layout(rng):
    cx, cy = MAP_W // 2, MAP_H // 2
    out = [Island(cx, cy, VILLAGE_RADIUS, K_VILLAGE)]
    for i in range(OUTER_ISLANDS):
        a = TAU * i / OUTER_ISLANDS - TAU / 4          # first one due north
        out.append(Island(int(cx + math.cos(a) * RING_RX),
                          int(cy + math.sin(a) * RING_RY),
                          rng.randint(19, 22), K_OUTER))
    # Mid-sized islands are placed by rejection sampling rather than a fixed
    # ring, so they never fuse into their neighbours no matter how the outer
    # ring is tuned.
    placed = 0
    for _ in range(400):
        if placed >= MID_ISLANDS:
            break
        a = rng.random() * TAU
        f = 0.45 + rng.random() * 0.30
        ix = int(cx + math.cos(a) * RING_RX * f)
        iy = int(cy + math.sin(a) * RING_RY * f)
        r = rng.randint(9, 12)
        if not (r + 3 <= ix < MAP_W - r - 3 and r + 3 <= iy < MAP_H - r - 3):
            continue
        if any(dist(ix, iy, o.cx, o.cy) < r + o.r + 7 for o in out):
            continue
        out.append(Island(ix, iy, r, K_MID))
        placed += 1
    return out


def _bridges(tiles, protected, islands):
    village = islands[0]
    outer = [i for i in islands if i.kind == K_OUTER]
    for o in outer:                                    # spokes from the village
        carve_bridge(tiles, protected, village.cx, village.cy, o.cx, o.cy)
    for k in range(len(outer)):                        # rim route around the ring
        a, b = outer[k], outer[(k + 1) % len(outer)]
        carve_bridge(tiles, protected, a.cx, a.cy, b.cx, b.cy)
    for m in islands:                                  # hook mid islands to their neighbour
        if m.kind != K_MID:
            continue
        near = min((i for i in islands if i.kind != K_MID),
                   key=lambda i: dist(m.cx, m.cy, i.cx, i.cy))
        carve_bridge(tiles, protected, m.cx, m.cy, near.cx, near.cy)


def _village_detail(tiles, protected, v):
    """A conduit ring and a handful of habitation blocks, plaza left clear."""
    for i in range(240):
        a = TAU * i / 240
        tx = int(v.cx + math.cos(a) * (v.r - 7))
        ty = int(v.cy + math.sin(a) * (v.r - 7) * 0.82)
        if in_bounds(tx, ty):
            k = ty * MAP_W + tx
            if tiles[k] == T_VILLAGE and k not in protected:
                tiles[k] = T_CONDUIT
    for (ox, oy, w, h) in ((-16, -9, 4, 3), (12, -10, 3, 4), (-15, 8, 3, 3),
                           (13, 9, 4, 3), (-2, -16, 5, 3), (-3, 14, 4, 3)):
        for ty in range(v.cy + oy, v.cy + oy + h):
            for tx in range(v.cx + ox, v.cx + ox + w):
                if in_bounds(tx, ty):
                    k = ty * MAP_W + tx
                    if tiles[k] in (T_VILLAGE, T_CONDUIT) and k not in protected:
                        tiles[k] = T_WALL


def _open_spots(tiles, reach, isl, inset=0.82):
    """Reachable, non-solid tiles well inside an island -- valid spawn ground."""
    spots = []
    r = isl.r
    for ty in range(max(0, isl.cy - r), min(MAP_H, isl.cy + r + 1)):
        for tx in range(max(0, isl.cx - r), min(MAP_W, isl.cx + r + 1)):
            if not in_hex(tx - isl.cx, ty - isl.cy, r * inset):
                continue
            k = ty * MAP_W + tx
            if not SOLID[tiles[k]] and k in reach:
                spots.append((tx, ty))
    return spots


def _centre(tx, ty):
    return (tx + 0.5) * TILE, (ty + 0.5) * TILE


def _populate(rng, tiles, islands, reach):
    enemies, pickups = [], []
    outer = [i for i in islands if i.kind == K_OUTER]
    mids = [i for i in islands if i.kind == K_MID]
    heavies = set(rng.sample(range(len(outer)), min(BREAKER_ISLANDS, len(outer))))
    pools = []
    for k, isl in enumerate(outer):
        want = [E_CRAWLER] * CRAWLERS_PER_OUTER + [E_DRONE] * DRONES_PER_OUTER
        if k in heavies:
            want.append(E_BREAKER)
        pools.append((isl, want))
    for isl in mids:
        pools.append((isl, [E_CRAWLER] * CRAWLERS_PER_MID))
    loot_ground = []
    for isl, want in pools:
        spots = _open_spots(tiles, reach, isl)
        rng.shuffle(spots)
        for t in want:
            if spots:
                enemies.append((t, *_centre(*spots.pop())))
        loot_ground.extend(spots)
    rng.shuffle(loot_ground)
    for kind, n in ((P_PLASMA, PLASMA_COUNT), (P_CORE, CORE_COUNT)):
        for _ in range(n):
            if loot_ground:
                pickups.append((kind, *_centre(*loot_ground.pop())))
    return tuple(enemies), tuple(pickups)


def generate(seed=WORLD_SEED):
    rng = random.Random(seed)
    tiles = bytearray(MAP_W * MAP_H)               # zero-filled == all T_VOID
    islands = _layout(rng)
    for isl in islands:
        paint_hex(tiles, isl.cx, isl.cy, isl.r,
                  T_VILLAGE if isl.kind == K_VILLAGE else T_FLOOR)
    protected = set()
    _bridges(tiles, protected, islands)
    for isl in islands:
        if isl.kind == K_VILLAGE:
            continue
        scatter_patches(tiles, rng, isl.cx, isl.cy, isl.r, isl.r // 3, T_FLOOR_ALT)
        scatter_walls(tiles, protected, rng, isl.cx, isl.cy, isl.r, 2 + isl.r // 4)
    _village_detail(tiles, protected, islands[0])

    stx, sty = islands[0].cx, islands[0].cy
    reach = flood_reachable(tiles, stx, sty)
    for _ in range(3):                             # safety net: never seal an island off
        cut = [i for i in islands if (i.cy * MAP_W + i.cx) not in reach]
        if not cut:
            break
        for i in cut:
            clear_walls(tiles, i.cx, i.cy, i.r)
        reach = flood_reachable(tiles, stx, sty)

    enemies, pickups = _populate(rng, tiles, islands, reach)
    sx, sy = _centre(stx, sty)
    return MapData(tiles, tuple(islands), sx, sy, enemies, pickups)

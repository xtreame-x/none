"""The three hostile archetypes, all driven by one small timer-based state
machine so their behaviour reads clearly and ports to C++ unchanged.

  Scrap Crawler -- fast and fragile, closes distance then lunges.
  Sentry Drone  -- hovers in a distance band, strafes, fires plasma.
  Breaker       -- slow and armoured, long telegraph then a heavy charge.

Every attack has a wind-up. That is deliberate: a telegraph is what makes the
dash feel like a skill instead of a dodge-roll lottery.
"""
import math
import random

from settings import (ENEMY_DEFS, DRONE_BAND_MIN, DRONE_BAND_MAX,
                      DRONE_STRAFE, BURST_LEAD)
from .entity import Entity
from .mathx import normalize, dist, TAU

S_IDLE, S_PURSUE, S_WINDUP, S_BURST, S_RECOVER = range(5)


class Enemy(Entity):
    __slots__ = ("d", "state", "timer", "home_x", "home_y", "strafe",
                 "burst_dx", "burst_dy")

    def __init__(self, type_id, x, y):
        d = ENEMY_DEFS[type_id]
        super().__init__(x, y, d.half, d.hp, kind=type_id)
        self.d = d
        self.state = S_IDLE
        self.timer = 0.0
        self.home_x = float(x)
        self.home_y = float(y)
        self.strafe = 1.0 if random.random() < 0.5 else -1.0
        self.burst_dx = 0.0
        self.burst_dy = 0.0

    # -------------------------------------------------------------- helpers
    @property
    def telegraph(self):
        """0..1 wind-up progress, for the renderer's warning flare."""
        if self.state != S_WINDUP or self.d.windup <= 0.0:
            return 0.0
        return 1.0 - max(0.0, self.timer) / self.d.windup

    def _sees(self, world, player, d):
        return d <= self.d.aggro and not world.line_blocked(
            self.x, self.y, player.x, player.y)

    # --------------------------------------------------------------- update
    def update(self, world, player, dt):
        """One fixed step. Returns a fire angle if it shot this step, else None."""
        self.tick_timers(dt)
        d = self.d
        pd = dist(self.x, self.y, player.x, player.y)
        self.timer -= dt
        shot = None

        if self.state == S_IDLE:
            if dist(self.x, self.y, self.home_x, self.home_y) > 26.0:
                self.steer(self.home_x, self.home_y, d.speed * 0.35, d.accel, dt)
            else:
                self.brake(d.accel, dt)
            if self._sees(world, player, pd):
                self.state = S_PURSUE

        elif self.state == S_PURSUE:
            self.face(player.x, player.y)
            if d.ranged:
                self._hover(player, pd, dt)
            else:
                self.steer(player.x, player.y, d.speed, d.accel, dt)
            ready = pd <= d.act_range and self.timer <= 0.0
            if ready and (not d.ranged or not world.line_blocked(
                    self.x, self.y, player.x, player.y)):
                self.state = S_WINDUP
                self.timer = d.windup
            elif pd > d.aggro * 1.4:
                self.state = S_IDLE

        elif self.state == S_WINDUP:
            self.face(player.x, player.y)
            self.brake(d.accel * 1.5, dt)
            if self.timer <= 0.0:
                if d.ranged:
                    shot = self.angle
                    self.state = S_RECOVER
                    self.timer = d.recover
                else:
                    self._aim_burst(player, pd)
                    self.state = S_BURST
                    self.timer = d.burst_time

        elif self.state == S_BURST:
            if d.burst_turn > 0.0:
                self._curve(player, dt)
            self.vx = self.burst_dx * d.burst_speed
            self.vy = self.burst_dy * d.burst_speed
            if self.timer <= 0.0:
                self.state = S_RECOVER
                self.timer = d.recover

        else:                                            # S_RECOVER
            self.brake(d.accel, dt)
            if self.timer <= 0.0:
                self.state = S_PURSUE

        if self.integrate(world, dt) and self.state == S_BURST:
            self.state = S_RECOVER                       # slammed into a wall
            self.timer = d.recover
        return shot

    def _aim_burst(self, player, pd):
        """Lock the lunge direction, leading the player's current velocity.

        Without the lead term a charge always lands behind a strafing target
        and the whole archetype feels harmless -- this was measured, not guessed.
        """
        t_hit = pd / max(1.0, self.d.burst_speed)
        ax = player.x + player.vx * t_hit * BURST_LEAD
        ay = player.y + player.vy * t_hit * BURST_LEAD
        nx, ny, m = normalize(ax - self.x, ay - self.y)
        if m == 0.0:
            nx, ny, _ = normalize(player.x - self.x, player.y - self.y)
        self.burst_dx, self.burst_dy = nx, ny

    def _curve(self, player, dt):
        """Let a charge bend slightly toward the player: dodge by timing, not walking."""
        want = math.atan2(player.y - self.y, player.x - self.x)
        cur = math.atan2(self.burst_dy, self.burst_dx)
        diff = (want - cur + math.pi) % TAU - math.pi
        lim = self.d.burst_turn * dt
        cur += lim if diff > lim else (-lim if diff < -lim else diff)
        self.burst_dx, self.burst_dy = math.cos(cur), math.sin(cur)

    def _hover(self, player, pd, dt):
        """Drone movement: hold a distance band and slide sideways inside it."""
        d = self.d
        if pd > DRONE_BAND_MAX:
            self.steer(player.x, player.y, d.speed, d.accel, dt)
        elif pd < DRONE_BAND_MIN:
            self.steer(2.0 * self.x - player.x, 2.0 * self.y - player.y,
                       d.speed, d.accel, dt)
        else:
            nx, ny, _ = normalize(player.x - self.x, player.y - self.y)
            self.steer(self.x - ny * 100.0 * self.strafe,
                       self.y + nx * 100.0 * self.strafe,
                       d.speed * DRONE_STRAFE, d.accel, dt)

    def deals_contact_damage(self):
        """Only the melee archetypes hurt on touch, and only mid-lunge."""
        return self.state == S_BURST and self.d.burst_speed > 0.0

    def knock(self, kx, ky):
        if self.state != S_BURST:                        # a charge will not be stopped
            self.vx += kx
            self.vy += ky
        if self.state == S_IDLE:
            self.state = S_PURSUE                        # getting shot wakes it up

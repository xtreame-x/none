"""One frame of player intent, decoupled from the input device.

The renderer fills this in from keyboard + mouse; the simulation never touches
pygame. Handy side effect: tests (and later, replays or a bot) can drive the
game by feeding in InputState directly.
"""
from typing import NamedTuple


class InputState(NamedTuple):
    move_x: float = 0.0     # -1..1, raw stick/WASD axis
    move_y: float = 0.0
    aim_x: float = 0.0      # world-space point being aimed at
    aim_y: float = 0.0
    fire: bool = False
    dash: bool = False


NEUTRAL = InputState()

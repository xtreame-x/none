"""Ground loot: plasma spheres (common) and nano cores (rare).

Straight out of the design doc's resource list. In the alpha they only feed the
run tally -- the village economy that consumes them is the next milestone.
"""
from settings import PICKUP_HALF, P_PLASMA


class Pickup:
    __slots__ = ("x", "y", "kind", "half", "alive", "phase")

    def __init__(self, kind, x, y):
        self.kind = kind
        self.x = float(x)
        self.y = float(y)
        self.half = PICKUP_HALF
        self.alive = True
        # Deterministic bob phase from position: neighbouring pickups drift out
        # of sync without needing a random number stored per object.
        self.phase = ((int(x) * 31 + int(y) * 17) % 628) / 100.0

    @property
    def is_plasma(self):
        return self.kind == P_PLASMA

"""The whole game simulation: one `step()` per fixed timestep, no rendering.

This is the layer that survives the rewrite. It imports nothing from pygame,
takes an InputState in and produces world state plus an event list out, so the
renderer (and any future test, replay or AI) is a pure consumer.
"""
import math

from settings import (WORLD_SEED, KNOCKBACK, PICKUP_MAGNET, P_PLASMA,
                      FIXED_DT)
from .world import World
from .player import Player
from .enemies import Enemy, S_BURST
from .projectile import player_bolt, enemy_bolt
from .pickups import Pickup
from .inputs import NEUTRAL
from .mathx import aabb_overlap

# event kinds the renderer listens for
EV_SPARK, EV_KILL, EV_DASH, EV_PICKUP, EV_HURT, EV_SHOT, EV_ENEMY_SHOT = range(7)

MAX_SEPARATION_PUSH = 1.2      # px per step, keeps bodies from stacking


class Simulation:
    def __init__(self, seed=WORLD_SEED):
        self.seed = seed
        self.world = World(seed)
        d = self.world.data
        self.player = Player(d.spawn_x, d.spawn_y)
        self.enemies = [Enemy(t, x, y) for (t, x, y) in d.enemies]
        self.pickups = [Pickup(k, x, y) for (k, x, y) in d.pickups]
        self.bolts = []
        self.events = []
        self.elapsed = 0.0
        self.hostiles_at_start = len(self.enemies)

    # ---------------------------------------------------------------- public
    @property
    def hostiles_left(self):
        return len(self.enemies)

    def step(self, inp=NEUTRAL, dt=FIXED_DT):
        self.events.clear()
        self.elapsed += dt
        p = self.player

        fire_angle, dashed = p.update(self.world, inp, dt)
        if dashed:
            self.events.append((EV_DASH, p.x, p.y, 0))
        if fire_angle is not None:
            mx, my = p.muzzle(fire_angle)
            self.bolts.append(player_bolt(mx, my, fire_angle))
            self.events.append((EV_SHOT, mx, my, fire_angle))

        self._update_enemies(dt)
        self._separate()
        self._update_bolts(dt)
        self._contact_damage()
        self._collect(dt)
        return self.events

    # --------------------------------------------------------------- systems
    def _update_enemies(self, dt):
        p = self.player
        for e in self.enemies:
            shot = e.update(self.world, p, dt)
            if shot is not None:
                off = e.half + 7.0
                bx = e.x + math.cos(shot) * off
                by = e.y + math.sin(shot) * off
                self.bolts.append(enemy_bolt(bx, by, shot, e.d.damage))
                self.events.append((EV_ENEMY_SHOT, bx, by, shot))

    def _separate(self):
        n = len(self.enemies)
        for i in range(n):
            a = self.enemies[i]
            for j in range(i + 1, n):
                b = self.enemies[j]
                dx = b.x - a.x
                dy = b.y - a.y
                rr = a.half + b.half
                d2 = dx * dx + dy * dy
                if d2 <= 1e-6 or d2 >= rr * rr:
                    continue
                d = math.sqrt(d2)
                push = min((rr - d) * 0.5, MAX_SEPARATION_PUSH)
                nx, ny = dx / d, dy / d
                if a.state != S_BURST:
                    a.x -= nx * push
                    a.y -= ny * push
                if b.state != S_BURST:
                    b.x += nx * push
                    b.y += ny * push

    def _update_bolts(self, dt):
        p = self.player
        killed = False
        for b in self.bolts:
            if b.update(self.world, dt):
                self.events.append((EV_SPARK, b.x, b.y, b.angle + math.pi))
                continue
            if not b.alive:
                continue
            if b.from_player:
                for e in self.enemies:
                    if not aabb_overlap(b.x, b.y, b.half, b.half,
                                        e.x, e.y, e.half, e.half):
                        continue
                    b.alive = False
                    p.damage_dealt += min(b.damage, e.hp)
                    nx, ny = math.cos(b.angle), math.sin(b.angle)
                    e.knock(nx * KNOCKBACK, ny * KNOCKBACK)
                    if e.hurt(b.damage):
                        p.kills += 1
                        killed = True
                        self.events.append((EV_KILL, e.x, e.y, e.kind))
                    else:
                        self.events.append((EV_SPARK, b.x, b.y, b.angle + math.pi))
                    break
            elif aabb_overlap(b.x, b.y, b.half, b.half,
                              p.x, p.y, p.half, p.half):
                b.alive = False
                nx, ny = math.cos(b.angle), math.sin(b.angle)
                if p.take_hit(b.damage, nx * 90.0, ny * 90.0):
                    self.events.append((EV_HURT, p.x, p.y, 0))
                else:
                    self.events.append((EV_SPARK, b.x, b.y, b.angle + math.pi))
        if killed:
            self.enemies = [e for e in self.enemies if e.alive]
        self.bolts = [b for b in self.bolts if b.alive]

    def _contact_damage(self):
        p = self.player
        for e in self.enemies:
            if not e.deals_contact_damage():
                continue
            if aabb_overlap(p.x, p.y, p.half, p.half, e.x, e.y, e.half, e.half):
                nx, ny = e.burst_dx, e.burst_dy
                if p.take_hit(e.d.damage, nx * 160.0, ny * 160.0):
                    self.events.append((EV_HURT, p.x, p.y, 0))

    def _collect(self, dt):
        p = self.player
        got = False
        reach = PICKUP_MAGNET + p.half
        for it in self.pickups:
            if abs(it.x - p.x) > reach or abs(it.y - p.y) > reach:
                continue
            if (it.x - p.x) ** 2 + (it.y - p.y) ** 2 > reach * reach:
                continue
            it.alive = False
            got = True
            if it.kind == P_PLASMA:
                p.plasma += 1
            else:
                p.cores += 1
            self.events.append((EV_PICKUP, it.x, it.y, it.kind))
        if got:
            self.pickups = [it for it in self.pickups if it.alive]

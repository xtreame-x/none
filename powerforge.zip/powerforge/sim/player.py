"""The player unit: 8-way accelerated movement, a dash with i-frames, and a
mouse-aimed plasma weapon.

Movement is acceleration-based rather than instant. That single choice is most
of why the game feels like a machine with mass instead of a cursor.
"""
import math
import random

from settings import (PLAYER_HALF, PLAYER_SPEED, PLAYER_ACCEL, PLAYER_FRICTION,
                      PLAYER_HP, PLAYER_IFRAME, PLAYER_REGEN_DELAY,
                      PLAYER_REGEN_RATE, DASH_SPEED, DASH_TIME, DASH_COOLDOWN,
                      DASH_IFRAME, FIRE_COOLDOWN, BOLT_SPREAD)
from .entity import Entity
from .mathx import approach, normalize


class Player(Entity):
    __slots__ = ("fire_cd", "dash_cd", "dash_t", "dash_dx", "dash_dy",
                 "iframe", "calm", "plasma", "cores", "damage_dealt", "kills")

    def __init__(self, x, y):
        super().__init__(x, y, PLAYER_HALF, PLAYER_HP)
        self.fire_cd = 0.0
        self.dash_cd = 0.0
        self.dash_t = 0.0
        self.dash_dx = 1.0
        self.dash_dy = 0.0
        self.iframe = 0.0
        self.calm = 0.0            # seconds since last damage taken
        self.plasma = 0
        self.cores = 0
        self.damage_dealt = 0.0
        self.kills = 0

    @property
    def dashing(self):
        return self.dash_t > 0.0

    def update(self, world, inp, dt):
        """Advance one fixed step. Returns (fire_angle or None, started_dash)."""
        self.tick_timers(dt)
        self.fire_cd = max(0.0, self.fire_cd - dt)
        self.dash_cd = max(0.0, self.dash_cd - dt)
        self.iframe = max(0.0, self.iframe - dt)
        self.calm += dt

        self.face(inp.aim_x, inp.aim_y)
        mx, my, _ = normalize(inp.move_x, inp.move_y)

        # ---------------------------------------------------------- dash
        started_dash = False
        if inp.dash and self.dash_cd <= 0.0 and not self.dashing:
            if mx == 0.0 and my == 0.0:                # no stick? dash where you aim
                mx, my = math.cos(self.angle), math.sin(self.angle)
            self.dash_dx, self.dash_dy = mx, my
            self.dash_t = DASH_TIME
            self.dash_cd = DASH_COOLDOWN
            self.iframe = max(self.iframe, DASH_IFRAME)
            started_dash = True

        if self.dashing:
            self.dash_t -= dt
            self.vx = self.dash_dx * DASH_SPEED
            self.vy = self.dash_dy * DASH_SPEED
        elif mx != 0.0 or my != 0.0:
            self.vx = approach(self.vx, mx * PLAYER_SPEED, PLAYER_ACCEL * dt)
            self.vy = approach(self.vy, my * PLAYER_SPEED, PLAYER_ACCEL * dt)
        else:
            self.brake(PLAYER_FRICTION, dt)

        if self.integrate(world, dt) and self.dashing:
            self.dash_t = 0.0                          # hitting a wall kills the dash

        # ---------------------------------------------------------- weapon
        fire_angle = None
        if inp.fire and self.fire_cd <= 0.0:
            self.fire_cd = FIRE_COOLDOWN
            fire_angle = math.atan2(inp.aim_y - self.y, inp.aim_x - self.x)
            fire_angle += random.uniform(-BOLT_SPREAD, BOLT_SPREAD)

        # ---------------------------------------------------------- repair
        if self.calm >= PLAYER_REGEN_DELAY and self.hp < self.hp_max:
            self.hp = min(self.hp_max, self.hp + PLAYER_REGEN_RATE * dt)

        return fire_angle, started_dash

    def take_hit(self, amount, kx=0.0, ky=0.0):
        """Returns True if the hit actually landed (i-frames can eat it)."""
        if self.iframe > 0.0:
            return False
        self.iframe = PLAYER_IFRAME
        self.calm = 0.0
        self.vx += kx
        self.vy += ky
        self.hurt(amount)
        return True

    def muzzle(self, angle):
        """World position the bolt should appear from, so it leaves the barrel."""
        off = self.half + 8.0
        return self.x + math.cos(angle) * off, self.y + math.sin(angle) * off

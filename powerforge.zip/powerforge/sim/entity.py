"""Shared entity base.

Flat public fields, no properties, no inheritance tricks -- this is a struct
with methods, which is what it will be in C++ too.
"""
import math

from .mathx import approach, normalize


class Entity:
    __slots__ = ("x", "y", "vx", "vy", "half", "hp", "hp_max", "alive",
                 "angle", "flash", "kind")

    def __init__(self, x, y, half, hp=1.0, kind=0):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.half = float(half)
        self.hp = float(hp)
        self.hp_max = float(hp)
        self.alive = True
        self.angle = 0.0          # facing, radians
        self.flash = 0.0          # seconds of "I just got hit" highlight
        self.kind = kind

    # ------------------------------------------------------------------ helpers
    def steer(self, tx, ty, speed, accel, dt):
        """Accelerate toward a desired velocity aimed at (tx, ty)."""
        nx, ny, d = normalize(tx - self.x, ty - self.y)
        self.vx = approach(self.vx, nx * speed, accel * dt)
        self.vy = approach(self.vy, ny * speed, accel * dt)
        return d

    def brake(self, friction, dt):
        self.vx = approach(self.vx, 0.0, friction * dt)
        self.vy = approach(self.vy, 0.0, friction * dt)

    def face(self, tx, ty):
        self.angle = math.atan2(ty - self.y, tx - self.x)

    def integrate(self, world, dt):
        """Apply velocity through the collision system; zero velocity on impact."""
        hx, hy = world.move_and_collide(self, self.vx * dt, self.vy * dt)
        if hx:
            self.vx = 0.0
        if hy:
            self.vy = 0.0
        return hx or hy

    def hurt(self, amount):
        self.hp -= amount
        self.flash = 0.12
        if self.hp <= 0.0:
            self.hp = 0.0
            self.alive = False
        return not self.alive

    def tick_timers(self, dt):
        if self.flash > 0.0:
            self.flash -= dt

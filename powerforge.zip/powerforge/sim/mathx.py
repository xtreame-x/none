"""Tiny scalar/vector helpers used by the simulation.

Deliberately operates on plain floats instead of a Vector class: it keeps the
simulation dependency-free and it is exactly how you would write this in C++.
"""
import math

TAU = math.tau


def clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def lerp(a, b, t):
    return a + (b - a) * t


def approach(current, target, max_delta):
    """Move `current` toward `target` by at most `max_delta`."""
    d = target - current
    if d > max_delta:
        return current + max_delta
    if d < -max_delta:
        return current - max_delta
    return target


def length(x, y):
    return math.sqrt(x * x + y * y)


def dist(ax, ay, bx, by):
    dx = bx - ax
    dy = by - ay
    return math.sqrt(dx * dx + dy * dy)


def dist_sq(ax, ay, bx, by):
    dx = bx - ax
    dy = by - ay
    return dx * dx + dy * dy


def normalize(x, y):
    """Return (nx, ny, len). Zero-length input returns (0, 0, 0)."""
    m = math.sqrt(x * x + y * y)
    if m < 1e-9:
        return 0.0, 0.0, 0.0
    return x / m, y / m, m


def aabb_overlap(ax, ay, ahx, ahy, bx, by, bhx, bhy):
    """Axis-aligned box overlap test, both boxes given as centre + half-extents."""
    return (abs(ax - bx) < ahx + bhx) and (abs(ay - by) < ahy + bhy)


def in_hex(dx, dy, r):
    """Point-in-regular-hexagon (flat-top, circumradius r), centred on origin.

    The world is built from floating hexagonal islands, so this is the brush
    the map generator paints with.
    """
    dx = abs(dx)
    dy = abs(dy)
    if dx > r:
        return False
    limit = 0.8660254 * r          # sqrt(3)/2 * r  -- the flat top/bottom
    slant = 1.7320508 * (r - dx)   # sqrt(3) * (r - |dx|) -- the angled edges
    return dy <= (limit if limit < slant else slant)

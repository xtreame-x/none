"""Low-level map painting helpers -- the "brushes" the generator draws with.

Everything here works on a flat `bytearray` of tile ids, indexed y * MAP_W + x.
A flat array (rather than a list of lists) is both faster in Python and the
exact layout you would use in C++.
"""
import math
from collections import deque

from settings import (MAP_W, MAP_H, SOLID, T_VOID, T_FLOOR, T_FLOOR_ALT,
                      T_WALL, T_BRIDGE, T_CONDUIT)
from .mathx import in_hex, TAU


def in_bounds(tx, ty):
    return 0 <= tx < MAP_W and 0 <= ty < MAP_H


def paint_hex(tiles, cx, cy, r, tile):
    """Fill a flat-top hexagon of tiles -- one floating island."""
    for ty in range(max(0, cy - r), min(MAP_H, cy + r + 1)):
        row = ty * MAP_W
        for tx in range(max(0, cx - r), min(MAP_W, cx + r + 1)):
            if in_hex(tx - cx, ty - cy, r):
                tiles[row + tx] = tile


def carve_bridge(tiles, protected, ax, ay, bx, by, half=1):
    """Lay a catwalk between two points, with a glowing conduit down the middle.

    Only VOID is overwritten, so a bridge never cuts a hole in an island.
    Every tile it touches is added to `protected` so wall clutter can't spawn
    on top of the one route between islands.
    """
    span = max(abs(bx - ax), abs(by - ay))
    steps = max(1, int(span) * 2)
    for i in range(steps + 1):
        t = i / steps
        x = int(round(ax + (bx - ax) * t))
        y = int(round(ay + (by - ay) * t))
        for oy in range(-half, half + 1):
            for ox in range(-half, half + 1):
                tx, ty = x + ox, y + oy
                if in_bounds(tx, ty):
                    k = ty * MAP_W + tx
                    if tiles[k] == T_VOID:
                        tiles[k] = T_BRIDGE
                    protected.add(k)
        if in_bounds(x, y):
            k = y * MAP_W + x
            if tiles[k] == T_BRIDGE:
                tiles[k] = T_CONDUIT


def scatter_patches(tiles, rng, cx, cy, r, count, tile, src=(T_FLOOR,)):
    """Blotch a cosmetic floor variant around an island so plating isn't uniform."""
    for _ in range(count):
        a = rng.random() * TAU
        rad = r * math.sqrt(rng.random())
        px = int(cx + math.cos(a) * rad)
        py = int(cy + math.sin(a) * rad)
        size = rng.randint(1, 3)
        for ty in range(py - size, py + size + 1):
            for tx in range(px - size, px + size + 1):
                if in_bounds(tx, ty) and (tx - px) ** 2 + (ty - py) ** 2 <= size * size:
                    k = ty * MAP_W + tx
                    if tiles[k] in src:
                        tiles[k] = tile


def scatter_walls(tiles, protected, rng, cx, cy, r, clusters):
    """Grow small clusters of machinery to break line of sight and give cover."""
    for _ in range(clusters):
        tx = ty = -1
        for _attempt in range(40):
            a = rng.random() * TAU
            rad = r * math.sqrt(rng.random()) * 0.9
            tx = int(cx + math.cos(a) * rad)
            ty = int(cy + math.sin(a) * rad)
            if in_bounds(tx, ty):
                k = ty * MAP_W + tx
                if tiles[k] in (T_FLOOR, T_FLOOR_ALT) and k not in protected:
                    break
        else:
            continue
        for _ in range(rng.randint(3, 9)):
            if in_bounds(tx, ty):
                k = ty * MAP_W + tx
                if tiles[k] in (T_FLOOR, T_FLOOR_ALT) and k not in protected:
                    tiles[k] = T_WALL
            tx += rng.randint(-1, 1)
            ty += rng.randint(-1, 1)


def clear_walls(tiles, cx, cy, r):
    """Undo wall clutter on one island (used when it sealed itself off)."""
    for ty in range(max(0, cy - r), min(MAP_H, cy + r + 1)):
        row = ty * MAP_W
        for tx in range(max(0, cx - r), min(MAP_W, cx + r + 1)):
            if in_hex(tx - cx, ty - cy, r) and tiles[row + tx] == T_WALL:
                tiles[row + tx] = T_FLOOR


def flood_reachable(tiles, start_tx, start_ty):
    """4-way flood fill of walkable tiles. Returns a set of flat indices.

    Used to guarantee every spawn point is actually reachable on foot, which
    is far more reliable than hoping the generator never seals a pocket.
    """
    start = start_ty * MAP_W + start_tx
    if SOLID[tiles[start]]:
        return set()
    seen = {start}
    q = deque((start,))
    while q:
        k = q.popleft()
        x = k % MAP_W
        for nk, ok in ((k - 1, x > 0), (k + 1, x < MAP_W - 1),
                       (k - MAP_W, k >= MAP_W), (k + MAP_W, k < MAP_W * MAP_H - MAP_W)):
            if ok and nk not in seen and not SOLID[tiles[nk]]:
                seen.add(nk)
                q.append(nk)
    return seen

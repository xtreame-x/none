"""A minimal PIL-backed stand-in for pygame.

pygame cannot be installed in this sandbox (PyPI is blocked), but the render
layer still has to be *executed* rather than eyeballed. This implements the
subset of the pygame API that Power Forge actually calls -- surfaces, blitting
(including additive), the draw primitives, rotation, fonts, clock and the
display/input shims -- on top of Pillow and numpy.

It is a verification harness, not a runtime: install() it, run the real game
loop, save real PNGs, then look at them. On a machine with pygame installed
nothing imports this file.
"""
import sys
import types

import numpy as np
from PIL import Image, ImageDraw, ImageFont

# --- flags / constants the game references ---------------------------------
SRCALPHA = 0x00010000
HWSURFACE = 0x00000001
DOUBLEBUF = 0x40000000
FULLSCREEN = 0x00000080
SCALED = 0x00000200
RESIZABLE = 0x00000010
BLEND_RGB_ADD = 1
BLEND_RGBA_ADD = 6

QUIT = 256
KEYDOWN = 768
KEYUP = 769
MOUSEBUTTONDOWN = 1025
MOUSEBUTTONUP = 1026
MOUSEMOTION = 1024

(K_a, K_b, K_c, K_d, K_e, K_f, K_g, K_h, K_i, K_j, K_k, K_l, K_m, K_n, K_o,
 K_p, K_q, K_r, K_s, K_t, K_u, K_v, K_w, K_x, K_y, K_z) = range(97, 123)
K_LEFT, K_RIGHT, K_UP, K_DOWN = 1073741904, 1073741903, 1073741906, 1073741905
K_SPACE = 32
K_ESCAPE = 27
K_RETURN = 13
K_LSHIFT = 1073742049
K_F1, K_F11 = 1073741882, 1073741892
KEY_COUNT = 512


class error(Exception):
    pass


# --------------------------------------------------------------------- helpers
def _col(c):
    if len(c) >= 4:
        return (int(c[0]), int(c[1]), int(c[2]), int(c[3]))
    return (int(c[0]), int(c[1]), int(c[2]), 255)


def _box(r):
    """pygame (x, y, w, h) -> PIL inclusive (x0, y0, x1, y1)."""
    x, y, w, h = int(r[0]), int(r[1]), int(r[2]), int(r[3])
    return (x, y, x + max(1, w) - 1, y + max(1, h) - 1)


def _overlap(dst, src, x, y):
    """Clip a blit by hand so nothing depends on PIL's out-of-range behaviour."""
    dw, dh = dst
    sw, sh = src
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(dw, x + sw), min(dh, y + sh)
    if x1 <= x0 or y1 <= y0:
        return None
    return x0, y0, x0 - x, y0 - y, x1 - x0, y1 - y0


def _add_blit(dst_img, src_img, x, y):
    """BLEND_RGB_ADD: saturating add of RGB, alpha untouched."""
    ov = _overlap(dst_img.size, src_img.size, x, y)
    if ov is None:
        return
    dx, dy, sx, sy, w, h = ov
    dst_region = dst_img.crop((dx, dy, dx + w, dy + h))
    src_region = src_img.crop((sx, sy, sx + w, sy + h))
    a = np.asarray(dst_region, dtype=np.uint16)
    b = np.asarray(src_region, dtype=np.uint16)
    out = a.copy()
    np.minimum(a[:, :, :3] + b[:, :, :3], 255, out=out[:, :, :3])
    dst_img.paste(Image.fromarray(out.astype(np.uint8), "RGBA"), (dx, dy))


# --------------------------------------------------------------------- Surface
class Surface:
    __slots__ = ("img", "d", "alpha_px", "_alpha")

    def __init__(self, size, flags=0, _img=None):
        if _img is not None:
            self.img = _img
            self.alpha_px = True
        else:
            w = max(1, int(size[0]))
            h = max(1, int(size[1]))
            self.alpha_px = bool(flags & SRCALPHA)
            fill = (0, 0, 0, 0) if self.alpha_px else (0, 0, 0, 255)
            self.img = Image.new("RGBA", (w, h), fill)
        self.d = ImageDraw.Draw(self.img)
        self._alpha = None

    # geometry
    def get_width(self):
        return self.img.size[0]

    def get_height(self):
        return self.img.size[1]

    def get_size(self):
        return self.img.size

    def get_rect(self, **kw):
        return (0, 0) + self.img.size

    # pixels
    def get_at(self, pos):
        return self.img.getpixel((int(pos[0]), int(pos[1])))

    def set_at(self, pos, color):
        x, y = int(pos[0]), int(pos[1])
        if 0 <= x < self.img.size[0] and 0 <= y < self.img.size[1]:
            self.img.putpixel((x, y), _col(color))

    def fill(self, color, rect=None):
        if rect is None:
            self.img.paste(_col(color), (0, 0) + self.img.size)
        else:
            self.d.rectangle(_box(rect), fill=_col(color))

    # conversion / copying
    def convert(self, *a):
        s = Surface((1, 1), 0, _img=self.img.copy())
        s.alpha_px = False
        return s

    def convert_alpha(self, *a):
        s = Surface((1, 1), 0, _img=self.img.copy())
        s.alpha_px = True
        return s

    def copy(self):
        s = Surface((1, 1), 0, _img=self.img.copy())
        s.alpha_px = self.alpha_px
        s._alpha = self._alpha
        return s

    def set_alpha(self, a):
        self._alpha = None if a is None else int(a)

    def get_alpha(self):
        return self._alpha

    def set_colorkey(self, *a):
        pass

    # blitting
    def blit(self, src, dest, area=None, special_flags=0):
        x, y = int(dest[0]), int(dest[1])
        if special_flags in (BLEND_RGB_ADD, BLEND_RGBA_ADD):
            _add_blit(self.img, src.img, x, y)
            return
        ov = _overlap(self.img.size, src.img.size, x, y)
        if ov is None:
            return
        dx, dy, sx, sy, w, h = ov
        im = src.img.crop((sx, sy, sx + w, sy + h))
        if src._alpha is not None:
            scale = src._alpha
            im = im.copy()
            im.putalpha(im.getchannel("A").point(lambda v: v * scale // 255))
            self.img.paste(im, (dx, dy), im)
        elif src.alpha_px:
            self.img.paste(im, (dx, dy), im)
        else:
            self.img.paste(im, (dx, dy))


# ------------------------------------------------------------------ draw calls
def _d_rect(surf, color, rect, width=0, *a, **kw):
    if width <= 0:
        surf.d.rectangle(_box(rect), fill=_col(color))
    else:
        surf.d.rectangle(_box(rect), outline=_col(color), width=int(width))


def _d_circle(surf, color, center, radius, width=0, *a, **kw):
    r = int(radius)
    if r < 1:
        return
    cx, cy = int(center[0]), int(center[1])
    box = (cx - r, cy - r, cx + r, cy + r)
    if width <= 0:
        surf.d.ellipse(box, fill=_col(color))
    else:
        surf.d.ellipse(box, outline=_col(color), width=int(width))


def _d_ellipse(surf, color, rect, width=0, *a, **kw):
    if width <= 0:
        surf.d.ellipse(_box(rect), fill=_col(color))
    else:
        surf.d.ellipse(_box(rect), outline=_col(color), width=int(width))


def _d_line(surf, color, p0, p1, width=1, *a, **kw):
    surf.d.line([(float(p0[0]), float(p0[1])), (float(p1[0]), float(p1[1]))],
                fill=_col(color), width=max(1, int(width)))


def _d_polygon(surf, color, points, width=0, *a, **kw):
    pts = [(float(p[0]), float(p[1])) for p in points]
    if len(pts) < 2:
        return
    if width <= 0:
        surf.d.polygon(pts, fill=_col(color))
        return
    for i in range(len(pts)):
        surf.d.line([pts[i], pts[(i + 1) % len(pts)]], fill=_col(color),
                    width=int(width))


# ------------------------------------------------------------------- transform
def _t_rotate(surf, deg):
    # NEAREST, because pygame's rotate is not antialiased either.
    img = surf.img.rotate(float(deg), expand=True, resample=Image.NEAREST)
    s = Surface((1, 1), 0, _img=img)
    s.alpha_px = True
    return s


def _t_scale(surf, size):
    img = surf.img.resize((max(1, int(size[0])), max(1, int(size[1]))),
                          Image.NEAREST)
    s = Surface((1, 1), 0, _img=img)
    s.alpha_px = surf.alpha_px
    return s


def _t_smoothscale(surf, size):
    img = surf.img.resize((max(1, int(size[0])), max(1, int(size[1]))),
                          Image.BILINEAR)
    s = Surface((1, 1), 0, _img=img)
    s.alpha_px = surf.alpha_px
    return s


def _t_flip(surf, fx, fy):
    img = surf.img
    if fx:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if fy:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
    s = Surface((1, 1), 0, _img=img)
    s.alpha_px = surf.alpha_px
    return s


# ------------------------------------------------------------------------ font
def _load_font(pt):
    try:
        return ImageFont.load_default(size=max(8, int(pt * 0.80)))
    except TypeError:                        # very old Pillow: bitmap default
        return ImageFont.load_default()


class Font:
    def __init__(self, path=None, size=20):
        self.pt = int(size)
        self.f = _load_font(self.pt)
        try:
            asc, desc = self.f.getmetrics()
            self.h = asc + desc
        except Exception:
            self.h = self.pt

    def _width(self, text):
        try:
            return int(self.f.getlength(text)) + 2
        except Exception:
            bb = self.f.getbbox(text)
            return int(bb[2]) + 2

    def get_height(self):
        return self.h

    def get_linesize(self):
        return self.h + 2

    def size(self, text):
        return (self._width(text), self.h)

    def render(self, text, aa=True, color=(255, 255, 255), background=None):
        text = text if text else " "
        s = Surface((self._width(text), self.h + 2), SRCALPHA)
        if background is not None:
            s.fill(background)
        s.d.text((1, 0), text, font=self.f, fill=_col(color))
        return s


# ----------------------------------------------------------------- input state
class _Keys:
    def __init__(self):
        self.held = set()

    def __getitem__(self, k):
        return k in self.held

    def __len__(self):
        return KEY_COUNT


_KEYS = _Keys()
_MOUSE_POS = [640, 360]
_MOUSE_BTN = [False, False, False]
_FLIPS = [0]
_SCREEN = [None]


class Clock:
    def tick(self, fps=0):
        return 16                            # deterministic 62.5 fps

    def tick_busy_loop(self, fps=0):
        return 16

    def get_fps(self):
        return 60.0

    def get_time(self):
        return 16


def init():
    return (0, 0)


def quit():
    return None


def get_init():
    return True


def _mk(_name, **attrs):
    m = types.ModuleType("pygame." + _name)
    for k, v in attrs.items():
        setattr(m, k, v)
    sys.modules["pygame." + _name] = m
    return m


# ------------------------------------------------------- display / image shims
def _set_mode(size, flags=0, depth=0, *a, **kw):
    _SCREEN[0] = Surface(size)
    return _SCREEN[0]


def _get_surface():
    return _SCREEN[0]


def _flip():
    _FLIPS[0] += 1


def _update(*a):
    _FLIPS[0] += 1


def _set_mouse(pos):
    _MOUSE_POS[0], _MOUSE_POS[1] = int(pos[0]), int(pos[1])


def _img_save(surf, path):
    surf.img.convert("RGB").save(path)


def _img_load(path):
    img = Image.open(path).convert("RGBA")
    s = Surface((1, 1), 0, _img=img)
    s.alpha_px = True
    return s


# -------------------------------------------------- harness-side input driving
def hold(*keys):
    _KEYS.held.update(keys)


def release(*keys):
    _KEYS.held.difference_update(keys)


def set_buttons(left=False, middle=False, right=False):
    _MOUSE_BTN[0], _MOUSE_BTN[1], _MOUSE_BTN[2] = left, middle, right


def flips():
    return _FLIPS[0]


def install():
    """Register this module as `pygame` for the rest of the process."""
    me = sys.modules[__name__]
    me.draw = _mk("draw", rect=_d_rect, circle=_d_circle, ellipse=_d_ellipse,
                  line=_d_line, lines=lambda s, c, cl, pts, w=1: None,
                  aaline=_d_line, polygon=_d_polygon, arc=lambda *a, **k: None)
    me.transform = _mk("transform", rotate=_t_rotate, scale=_t_scale,
                       smoothscale=_t_smoothscale, flip=_t_flip)
    me.font = _mk("font", Font=Font, SysFont=lambda n, s, *a, **k: Font(None, s),
                  init=lambda: None, get_init=lambda: True,
                  get_default_font=lambda: "default")
    me.time = _mk("time", Clock=Clock, get_ticks=lambda: 0,
                  wait=lambda ms: None, delay=lambda ms: None)
    me.display = _mk("display", set_mode=_set_mode, get_surface=_get_surface,
                     set_caption=lambda *a: None, flip=_flip, update=_update,
                     toggle_fullscreen=lambda: 0, get_init=lambda: True,
                     init=lambda: None, quit=lambda: None,
                     set_icon=lambda *a: None)
    me.event = _mk("event", get=lambda *a: [], pump=lambda: None,
                   clear=lambda *a: None, post=lambda e: None,
                   set_grab=lambda v: None)
    me.key = _mk("key", get_pressed=lambda: _KEYS, set_repeat=lambda *a: None,
                 name=lambda k: str(k))
    me.mouse = _mk("mouse", get_pos=lambda: tuple(_MOUSE_POS),
                   get_pressed=lambda *a: tuple(_MOUSE_BTN),
                   set_pos=_set_mouse, set_visible=lambda v: None,
                   get_focused=lambda: True)
    me.image = _mk("image", save=_img_save, load=_img_load)
    me.mixer = _mk("mixer", init=lambda *a, **k: None, quit=lambda: None,
                   get_init=lambda: None)
    sys.modules["pygame"] = me
    return me

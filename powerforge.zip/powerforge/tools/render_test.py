"""Runs the real game loop against the PIL-backed pygame stub.

This is the only way to actually execute the render layer in this environment:
it installs tools/fakepygame as `pygame`, boots the genuine Game object, drives
it with a scripted bot, writes PNGs of the states worth looking at, and asserts
the loop stayed healthy the whole time.
"""
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fakepygame                                        # noqa: E402
fakepygame.install()
import pygame                                            # noqa: E402  (the stub)

from settings import TILE, FIXED_DT, WORLD_W, WORLD_H     # noqa: E402
from sim.inputs import InputState                         # noqa: E402
from sim.enemies import S_WINDUP, S_BURST                 # noqa: E402
from sim.sim import EV_KILL, EV_HURT, EV_PICKUP           # noqa: E402
from game import Game                                     # noqa: E402

SHOTS = os.path.join(ROOT, "shots")
FIRE_RANGE = 560.0
KEEP_AWAY = 190.0


def nearest_enemy(sim):
    p = sim.player
    best, bd = None, 1e18
    for e in sim.enemies:
        d = (e.x - p.x) ** 2 + (e.y - p.y) ** 2
        if d < bd:
            best, bd = e, d
    return best, math.sqrt(bd) if best else 0.0


def bot(sim, t):
    """Good enough to look like a player: close in, orbit, shoot, dash sometimes."""
    p = sim.player
    e, d = nearest_enemy(sim)
    if e is None:
        return InputState(0.0, 0.0, 1.0, 0.0, False, False)
    ax, ay = e.x - p.x, e.y - p.y
    n = math.hypot(ax, ay) or 1.0
    ax, ay = ax / n, ay / n
    if d > KEEP_AWAY:
        mx, my = ax, ay
    else:                                                # orbit at knife range
        s = 1.0 if int(t * 0.7) % 2 == 0 else -1.0
        mx, my = -ay * s, ax * s
    return InputState(mx, my, ax, ay, d < FIRE_RANGE,
                      d < 120.0 and int(t * 3.0) % 7 == 0)


def shoot(g, name):
    path = os.path.join(SHOTS, name)
    pygame.image.save(g.screen, path)
    return path


def look(g):
    """Cheap image stats so a black or single-colour frame cannot pass."""
    a = np.asarray(g.screen.img.convert("RGB"), dtype=np.uint8)[::3, ::3]
    flat = a.reshape(-1, 3)
    colours = len(np.unique(flat, axis=0))
    return float(flat.mean()), float(flat.std()), colours


def place_near(g, e, want=150.0):
    """Teleport the player next to a target, avoiding geometry."""
    p = g.sim.player
    w = g.sim.world
    for k in range(24):
        a = math.tau * k / 24.0
        x = e.x + math.cos(a) * want
        y = e.y + math.sin(a) * want
        if w.solid_px(x, y) or w.solid_px(x - 14, y) or w.solid_px(x + 14, y):
            continue
        p.x, p.y, p.vx, p.vy = x, y, 0.0, 0.0
        g.cam.snap(p)
        return True
    return False


def drive(g, frames, log=None, use_bot=True):
    for _ in range(frames):
        inp = bot(g.sim, g.sim.elapsed) if use_bot else InputState()
        g.advance(inp, FIXED_DT)
        if log is not None:
            for ev in g.sim.events:
                log[ev[0]] = log.get(ev[0], 0) + 1


def main():
    os.makedirs(SHOTS, exist_ok=True)
    t_boot = time.perf_counter()
    g = Game(headless=True)
    boot_ms = (time.perf_counter() - t_boot) * 1000.0
    print("boot            %.0f ms  (procedural art + %d minimap tiles)"
          % (boot_ms, g.hud.minimap.get_width() * g.hud.minimap.get_height()))

    saved = []
    # ---- 1. village, first frame -------------------------------------------
    drive(g, 2, use_bot=False)
    assert g.sim.world.in_village(g.sim.player.x, g.sim.player.y), \
        "player should spawn inside the village"
    saved.append(shoot(g, "01_village_spawn.png"))
    mean, std, cols = look(g)
    assert std > 12.0 and cols > 200, "village frame looks flat (std %.1f, %d cols)" % (std, cols)

    # ---- 2. out on a raid island -------------------------------------------
    outer = [e for e in g.sim.enemies if e.kind == 0]
    assert outer, "no crawlers to hunt"
    place_near(g, outer[0], 260.0)
    log = {}
    drive(g, 150, log)
    saved.append(shoot(g, "02_raid_island.png"))

    # ---- 3. telegraph + burst ----------------------------------------------
    breakers = [e for e in g.sim.enemies if e.kind == 2]
    assert breakers, "no breakers on the map"
    place_near(g, breakers[0], 210.0)
    got_windup = got_burst = False
    for _ in range(900):
        drive(g, 1, log)
        if not breakers[0].alive:
            break
        st = breakers[0].state
        if st == S_WINDUP and not got_windup and breakers[0].telegraph > 0.45:
            got_windup = True
            saved.append(shoot(g, "03_telegraph.png"))
        elif st == S_BURST and not got_burst:
            got_burst = True
            saved.append(shoot(g, "04_burst_charge.png"))
        if got_windup and got_burst:
            break
    assert got_windup, "breaker never telegraphed while on camera"
    assert got_burst, "breaker never charged while on camera"

    # ---- 4. debug overlay + sustained run, profiled -------------------------
    g.hud.debug = True
    t0 = time.perf_counter()
    drive(g, 400, log)
    wall = time.perf_counter() - t0
    saved.append(shoot(g, "05_debug_overlay.png"))
    g.hud.debug = False

    print("loop            %d frames in %.2fs  (%.1f ms/frame with the PIL stub)"
          % (400, wall, wall / 400.0 * 1000.0))
    print("last frame      sim %.2f ms   draw %.2f ms (stub, not pygame)"
          % (g.hud.step_ms, g.hud.draw_ms))
    print("events          kills %d   hurt %d   pickups %d"
          % (log.get(EV_KILL, 0), log.get(EV_HURT, 0), log.get(EV_PICKUP, 0)))
    print("state           hp %.0f   damage %.0f   kills %d   plasma %d   cores %d"
          % (g.sim.player.hp, g.sim.player.damage_dealt, g.sim.player.kills,
             g.sim.player.plasma, g.sim.player.cores))
    print("world           %d hostiles left of %d   %d chunks cached"
          % (g.sim.hostiles_left, g.sim.hostiles_at_start,
             g.renderer.tiles.cached))

    assert log.get(EV_KILL, 0) > 0, "bot killed nothing through the real loop"
    assert log.get(EV_HURT, 0) > 0, "player was never hit -- enemies are harmless"
    assert g.frames == fakepygame.flips(), "a frame was drawn without a flip"

    p = g.sim.player
    assert 0.0 < p.x < WORLD_W and 0.0 < p.y < WORLD_H, "player left the world"
    assert not g.sim.world.solid_px(p.x, p.y), "player ended up inside geometry"

    # ---- 5. paused, dead and cleared UI states -----------------------------
    g.paused = True
    was = g.sim.elapsed
    drive(g, 3, use_bot=False)
    assert g.sim.elapsed == was, "simulation advanced while paused"
    saved.append(shoot(g, "06_paused.png"))
    g.paused = False

    p.hp, p.alive = 0.0, False
    drive(g, 2, use_bot=False)
    saved.append(shoot(g, "07_defeat.png"))

    g._key(pygame.K_r)                       # restart path
    assert g.sim.player.alive and g.sim.hostiles_left == g.sim.hostiles_at_start, \
        "restart did not rebuild the run"
    drive(g, 2, use_bot=False)

    g.sim.enemies = []                       # victory banner render path
    drive(g, 2, use_bot=False)
    saved.append(shoot(g, "08_cleared.png"))

    # ---- 6. every saved frame must actually contain a picture ---------------
    print()
    for path in saved:
        m, s, c = look_file(path)
        size = os.path.getsize(path) // 1024
        print("  %-26s %4d KB  mean %5.1f  std %5.1f  %5d colours"
              % (os.path.basename(path), size, m, s, c))
        assert s > 10.0, "%s is nearly featureless" % path
        assert c > 150, "%s has almost no colour variety" % path

    print("\nOK  %d frames drawn, %d screenshots written to %s"
          % (g.frames, len(saved), SHOTS))
    return 0


def look_file(path):
    from PIL import Image
    a = np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8)[::3, ::3]
    flat = a.reshape(-1, 3)
    return (float(flat.mean()), float(flat.std()),
            len(np.unique(flat, axis=0)))


if __name__ == "__main__":
    sys.exit(main())

"""Headless simulation harness -- runs the game with no window and no pygame.

    python3 tools/sim_test.py

Because the whole simulation is pygame-free, this exercises world generation,
collision, all three enemy state machines, projectiles and pickups at full
speed, and asserts the invariants that matter.
"""
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import settings as S                                          # noqa: E402
from sim.sim import Simulation                                # noqa: E402
from sim.inputs import InputState                             # noqa: E402
from sim.mathx import dist, TAU                               # noqa: E402
from sim.mapbrush import flood_reachable                      # noqa: E402
from sim import enemies as EN                                 # noqa: E402

TILE_NAMES = ("void", "floor", "floor_alt", "wall", "bridge", "village", "conduit")
STATE_NAMES = ("idle", "pursue", "windup", "burst", "recover")


def report_map(sim):
    data = sim.world.data
    counts = [0] * S.T_COUNT
    for v in data.tiles:
        counts[v] += 1
    total = len(data.tiles)
    walk = total - counts[S.T_VOID] - counts[S.T_WALL]
    print(f"map        : {S.MAP_W}x{S.MAP_H} tiles = {S.WORLD_W}x{S.WORLD_H} px "
          f"({S.WORLD_W / S.WINDOW_W:.1f} x {S.WORLD_H / S.WINDOW_H:.1f} screens)")
    print(f"islands    : {len(data.islands)}  (village 1, "
          f"outer {sum(1 for i in data.islands if i.kind == 2)}, "
          f"mid {sum(1 for i in data.islands if i.kind == 1)})")
    print(f"walkable   : {walk} tiles, {100.0 * walk / total:.1f}% of the grid")
    print("             " + "  ".join(f"{TILE_NAMES[i]}={n}" for i, n in enumerate(counts)))
    print(f"hostiles   : {len(sim.enemies)}  ("
          + ", ".join(f"{sum(1 for e in sim.enemies if e.kind == k)} "
                      f"{S.ENEMY_DEFS[k].name}" for k in range(3)) + ")")
    print(f"loot       : {len(sim.pickups)}   spawn: ({sim.player.x:.0f}, {sim.player.y:.0f})")


def check_reachability(sim):
    """Every island centre must be walkable from the village -- no dead islands."""
    v = sim.world.data.islands[0]
    reach = flood_reachable(sim.world.data.tiles, v.cx, v.cy)
    bad = [i for i in sim.world.data.islands
           if (i.cy * S.MAP_W + i.cx) not in reach]
    assert not bad, f"{len(bad)} island(s) unreachable on foot: {bad}"
    off = sum(1 for (_, x, y) in sim.world.data.enemies
              if (int(y // S.TILE) * S.MAP_W + int(x // S.TILE)) not in reach)
    assert off == 0, f"{off} enemies spawned in unreachable pockets"
    print(f"reachable  : {len(reach)} tiles from the village, all islands connected")


def place_near(sim, e, want):
    for r in (want, want * 0.8, want * 1.25, 150.0, 110.0):
        for k in range(32):
            a = TAU * k / 32
            x, y = e.x + math.cos(a) * r, e.y + math.sin(a) * r
            if (not sim.world.solid_px(x, y)
                    and not sim.world.line_blocked(x, y, e.x, e.y)):
                return x, y
    return None


def combat_drill(sim, type_id, budget=2400):
    """Two phases against one enemy of `type_id`.

    Phase 1 -- hold fire and let it come: proves the AI closes, telegraphs,
               commits to its attack and can actually hurt you.
    Phase 2 -- shoot back: proves the weapon, hitboxes and kill accounting work.
    """
    target = next((e for e in sim.enemies if e.kind == type_id), None)
    assert target is not None, f"no {S.ENEMY_DEFS[type_id].name} on the map"
    spot = place_near(sim, target, 260.0)
    assert spot, "could not find open ground near the target"
    p = sim.player
    p.x, p.y = spot
    p.vx = p.vy = 0.0
    p.hp = p.hp_max
    p.iframe = 0.0
    dmg0, kills0 = p.damage_dealt, p.kills
    seen = set()
    hits_taken = 0
    rng = random.Random(3 + type_id)

    def drive(steps, fire):
        nonlocal hits_taken
        for i in range(steps):
            seen.add(target.state)
            d = dist(p.x, p.y, target.x, target.y)
            dx, dy = target.x - p.x, target.y - p.y
            mx, my = (dx, dy) if d > 240.0 else (-dy, dx)      # close, then strafe
            hp_before = p.hp
            sim.step(InputState(mx, my, target.x, target.y,
                                fire=fire, dash=fire and rng.random() < 0.004),
                     S.FIXED_DT)
            if p.hp < hp_before:
                hits_taken += 1
            if not p.alive:
                p.alive, p.hp, p.iframe = True, p.hp_max, 0.0  # keep the drill going
            if not target.alive:
                return i + 1
        return steps

    approach = drive(600, fire=False)
    hp_after_approach = p.hp
    fight = drive(budget, fire=True)

    name = S.ENEMY_DEFS[type_id].name
    print(f"  {name:<14} reached+attacked in {approach:>4} steps "
          f"(hp {p.hp_max:.0f}->{hp_after_approach:.0f}, {hits_taken} hits taken)"
          f" | killed in {fight:>4} steps, {p.damage_dealt - dmg0:.0f} dmg")
    print(f"                 states seen: {sorted(STATE_NAMES[s] for s in seen)}")
    assert not target.alive, f"{name} survived {budget} steps -- weapon or hitbox broken"
    assert p.kills > kills0, "kill was not counted"
    assert EN.S_PURSUE in seen, f"{name} never pursued the player"
    assert EN.S_WINDUP in seen, f"{name} never telegraphed an attack"
    assert hits_taken > 0, f"{name} never managed to damage a stationary player"
    return seen


def roam(sim, steps):
    """Wander the map for a while, asserting nothing tunnels or NaNs out."""
    rng = random.Random(23)
    p = sim.player
    a = 0.0
    for i in range(steps):
        if i % 90 == 0:
            a = rng.random() * TAU
        sim.step(InputState(math.cos(a), math.sin(a),
                            p.x + math.cos(a) * 50.0, p.y + math.sin(a) * 50.0,
                            fire=i % 30 < 6, dash=i % 240 == 0), S.FIXED_DT)
        assert 0.0 < p.x < S.WORLD_W and 0.0 < p.y < S.WORLD_H, f"left the map at {i}"
        assert not sim.world.solid_px(p.x, p.y), f"clipped into geometry at step {i}"
        if not p.alive:
            p.alive, p.hp = True, p.hp_max


def main():
    random.seed(7)
    t0 = time.perf_counter()
    sim = Simulation(S.WORLD_SEED)
    print(f"worldgen   : {(time.perf_counter() - t0) * 1000.0:.0f} ms")
    report_map(sim)
    check_reachability(sim)
    assert not sim.world.solid_px(sim.player.x, sim.player.y), "spawn is inside a wall"
    for t, x, y in sim.world.data.enemies:
        assert not sim.world.solid_px(x, y), "an enemy spawned inside a wall"

    print("\ncombat drills (player vs one enemy, fight to the death)")
    seen = set()
    for k in range(3):
        seen |= combat_drill(sim, k)
    assert EN.S_BURST in seen, "no melee archetype ever committed to a lunge/charge"

    print("\nroaming 5400 steps (90s) ...")
    t0 = time.perf_counter()
    roam(sim, 5400)
    el = time.perf_counter() - t0
    p = sim.player
    print(f"perf       : {el / 5400 * 1000.0:.3f} ms/step "
          f"({5400 / el:.0f} steps/sec vs the 60 we need -> "
          f"{5400 / el / 60.0:.0f}x headroom)")
    print(f"totals     : {p.kills} kills, {p.damage_dealt:.0f} damage, "
          f"{p.plasma} plasma, {p.cores} cores, {sim.hostiles_left} hostiles left")
    print("\nOK -- simulation stable")


if __name__ == "__main__":
    main()
